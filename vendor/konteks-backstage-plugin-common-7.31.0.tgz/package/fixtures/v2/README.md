# Shared v2 wire fixtures

Canonical examples of accepted ticket continuation, estimates, tokens, and settlement integrity contracts.
They ship inside the published package so consumers in other languages — the Go
E2E controller, Python ingestion — validate **the same bytes** this package
parses, instead of a re-typed copy that drifts.

## Shape

Every file is an envelope:

```json
{
  "description": "why this example exists and what it demonstrates",
  "payload": { }
}
```

Validate `payload` directly against the corresponding schema. It needs no
pre-processing: every v2 schema is strict, and `payload` contains exactly the
fields the schema declares. The `description` sits outside it so the fixture can
explain itself without a reader having to know to strip a field first.

| File | Schema |
|---|---|
| `pm-accepted-ticket-contract-v1.json` | `PmAcceptedTicketSuccessorContextSchema` |
| `pm-repository-confirmation-progress-v1.json` | `PmRepositoryConfirmationSchema` |
| `settlement-snapshot-v2.json` | `SettlementSnapshotV2Schema` |
| `meter-occurrence-v2.json` | `MeterOccurrenceV2Schema` |
| `provider-call-observation-v2.json` | `ProviderCallObservationV2Schema` |
| `provider-money-position-v1.json` | `ProviderMoneyPositionV1Schema` |
| `estimate-feature-snapshot-v1.json` | `EstimateFeatureSnapshotV1Schema` |
| `estimate-outcome-v1.json` | `EstimateOutcomeV1Schema` |
| `forecast-profile-v1.json` | `ForecastProfileV1Schema` |
| `estimate-derivation-v1.json` | `EstimateDerivationV1Schema` |
| `economic-guidance-projection-v1.json` | `EconomicGuidanceProjectionV1Schema` |
| `session-runtime-transition-v1.json` | `RemoteRecoveryNoticeSchema` |
| `harness-execution-session-handoff-v1.json` | `HarnessExecutionSessionHandoffRequestSchema` |
| `remote-execution-continuation-policy-v1.json` | `RemoteExecutionContinuationPolicySchema` |

## What these examples deliberately show

They encode the honest shapes rather than the convenient ones, because those are
the cases a consumer is most likely to get wrong:

- an expired reservation settling as `unsettled` with zero capture and no ledger
  entry, rather than a receipt claiming Story Points;
- a minute quantity that reproduces its own single ceiling from retained
  milliseconds and spans more than one lease;
- a Codex call whose cached input is a **subset** of total input, and whose
  provider money is unavailable with a reason instead of zero;
- an estimate-time feature snapshot with explicit unknown topology provenance;
- a reconciled terminal outcome that is eligible only after feature capture;
- a shadow forecast profile with a structured, non-executable cohort selector;
- a deterministic derivation that falls back independently per dimension; and
- armed, advisory-only model guidance whose checkpoint arm stays independent.
- a negotiated continuation policy that can keep only one exact ACP operation
  active, never permits local tools, and states every authority deadline that
  still fences it.

No fixture contains an email address, prompt, tool result, provider body, or
credential, and a test asserts it.

## Accepted ticket continuation

`pm-accepted-ticket-contract-v1.json` carries the raw
`PmAcceptedTicketSuccessorContextSchema` payload. Its PM-owned contract binds
schema version 1, the accepted breakdown revision, ticket correlation, and static
local and cross-initiative dependency edges. Core supplies the separate current
permission-filtered dependency context. That context retains initiative identity
and evidence, and explicitly accounts for unavailable accepted ticket IDs.

The Common codec tests pin the exact canonical JSON and UTF-8 bytes. Only the
PM-owned static body enters the server's SHA-256 digest; live dependency progress
and the Core-owned locked repository scope retain their existing owners. Schema
parsing verifies shape and correlation, not current acceptance, permissions or a
cryptographic digest.

## Unconfirmed repository progress

`pm-repository-confirmation-progress-v1.json` is a closed read projection for an
actor's original requested repository and branch. It grants no repository access
or permission to Accept a breakdown. Consumers still enforce current
authorization and actor, tenant, ticket and revision scope.

The published `fixtures/project-management/pm-repository-confirmation-progress-v1.json`
contains the separate valid/invalid conformance matrix mirrored by the App schema
tests; it is test data, not a wire payload.
