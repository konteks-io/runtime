# @konteks/backstage-plugin-common

Shared types, constants, and contracts for Konteks platform components — Backstage plugins, agent harness, and core.

Runtime dependency: `zod` for schema validation at trust boundaries. Dev dependencies: `typescript`, `vitest`.

## Modules

### `remote-instance-internal` — Native Recovery Snapshots

Server-only recovery contracts expose strict unsigned
`RemoteReconnectIntentSnapshotSchema` and
`RemoteReconciliationReceiptSnapshotSchema` for persistence before a network
attempt. Their snapshot digest helpers use the same semantic bytes as the signed
request helpers, without retaining proof, connection or lease material. Receipt
ordering, unique identities and terminal-evidence correlation remain identical
in both forms. Signed request helpers still require actual transport proof.
These schemas do not establish durable storage, Core acceptance or permission to
resume work; those remain responsibilities of their runtime owners.

**Turn money** (`economics.ts`). `AgentTurnUsageObservationSchema` is a union
on `moneyBasis`: `unavailable_local_subscription` (a plan; no provider, model
or cost can appear) or `pay_per_use` (the person's own key or credit), which
names the route `provider`, optionally the `model`, and the agent's
`reportedCost` in USD micros when it reports one (OpenCode's cost delta;
DeepSeek Harness reports none). `costSource` says where that cost came from:
`provider_reported` (the default) or `list_price_estimate`, the connector's
measured tokens times the catalogue's list price (Google Antigravity with a
Gemini key), which must name its `model` and `pricingSnapshotId`.
`agentTurnUsageToProviderCall` ingests a reported cost as provider money
(`provider_billed`, `provider_reported`), an estimate as `locally_estimated`
money naming its price (never provider money), and a pay-per-use turn without
a cost as `provider_does_not_report`, never zero.

**Site-started agent login** (`agent-login.ts`). A person starts Codex's,
Claude Code's or OpenCode's sign-in from the site; the connector runs the
agent's own login on the machine and only a provider link and a device code
cross Konteks. OpenCode names which subscription to start (`loginOption`,
required for `opencode` and refused for the others): the reviewed table
`OPENCODE_LOGIN_OPTIONS` maps each option to OpenCode's integration and
`--method` id, how the person finishes (`device_code` for the OpenCode Console
account, ChatGPT Plus/Pro headless, GitHub Copilot and SuperGrok;
`machine_browser` for GitLab and Poe, whose only method needs a callback on the
machine) and the provider hosts a link may point at. A connector advertises
`agent-login-opencode-v1` plus one `agent-login-opencode:<option>` capability
per sign-in its installed OpenCode offers (`openCodeLoginOptionFor` maps
OpenCode's own list, `advertisedOpenCodeLoginOptions` reads it back). Google
Antigravity names its sign-in the same way (`ANTIGRAVITY_LOGIN_OPTIONS`:
`gemini-enterprise`, Antigravity's ACP `oauth-business`, and `google-account`,
`oauth-personal`, held back by `ANTIGRAVITY_GOOGLE_SIGN_IN_RELEASED`), both in
the machine's browser with links only to `accounts.google.com`; a Gemini
Enterprise start carries `gcp {project, location}` (`AgentLoginGcpSchema`),
which nothing else may carry. The capabilities are `agent-login-antigravity-v1`
plus `agent-login-antigravity:<option>` (`advertisedAntigravityLoginOptions`
offers only released ones). A Gemini API key is typed on the machine, never
started from the site. Read the method through
`agentLoginMethod(agentId, loginOption)`, the per-option capability through
`agentLoginOptionCapability(agentId, loginOption)`, and check links with
`agentLoginUrlAllowed(agentId, url, loginOption)`.

### `agent-setup`, `retired-agents` — Native Agents Only (read vs write)

Every agent runs on the person's own computer over ACP (Claude Code, Codex,
DeepSeek Harness, OpenCode 2, Google Antigravity). `opencode` was retired in
7.0.0 and is a native agent again since 7.1.0, so a stored `opencode` value
reads as the person's own OpenCode 2; `antigravity` is new in 7.1.0. Each setup, profile and route contract has two sides:

- **READ** (`AgentSetupCapabilitiesResponseSchema`, `RuntimeOptionSchema`,
  `ExecutionProfileConfigurationSchema`, `ResolvedExecutionRouteManifestSchema`,
  …) still parses stored history: `provider_connection` routes with
  `api_key`/`subscription_oauth` credentials, provider connections, retired
  agents. `providerConnections` on the capabilities response is optional.
- **WRITE** (`AgentSetupCapabilitiesResponseWriteSchema`,
  `ExecutionProfileConfigurationWriteSchema` with its role/sub-agent parts)
  admits only `managed_local_auth` on `NATIVE_AGENT_RUNTIME_IDS` and never a
  `providerConnectionId`; a retired agent is refused with
  `retiredAgentMessage()`.

`resolveExecutionRouteManifest` defaults a new route to `managed_local_auth`;
a stored configuration that names a connection or hosted credential kind
resolves as it always did. IAM keeps the `provider_connection` resource type
for stored bindings, and `RETIRED_PERMISSION_IDS` /
`RETIRED_IAM_OPERATION_KEYS` must be registered `retired`.

### `known-models` — Known Models: recognised, tiered and priced automatically

`@konteks/backstage-plugin-common/known-models` (a subpath; the root entry
never loads the data) is the known-model catalogue and everything that reads
it (System One §6a):

- **Catalogue (KM1).** `catalogue.generated.ts` is generated from models.dev by
  `scripts/generate-known-models.mjs` (`npm run models:generate`, `--check`
  for staleness) over a reviewed list of PROVIDERS (the three agents'
  providers plus those DeepSeek Harness fronts through pi-ai); every
  tool-calling text model under them is kept. `.gitea/workflows/known-models.yml`
  regenerates it weekly and opens a PR when it changed. Lookups:
  `getKnownModel(provider, model)`, `findKnownModelFacts`.
- **Recognition (KM2).** `recogniseNativeModel(agentId, value, signed?)` turns
  an ACP model value into `known | recognised | unrecognised` with a canonical
  identity (the publisher's namespace, what model independence compares) and
  a route (what the agent reaches; the catalogue and price key). Rules:
  Claude Code full ids pass through and aliases resolve through
  `CLAUDE_CODE_MODEL_ALIASES`; Codex is `openai`/id with an effort suffix
  dropped; dsh `["provider","model"]` maps provider refs
  (`DSH_PROVIDER_REFS`) and, through a gateway, names the `vendor/` publisher.
  OpenCode 2 is `provider/model[/variant]` split at the first `/`, provider
  ids being models.dev ids; a trailing variant (reasoning effort, thinking
  budget) is dropped unless the catalogue knows the whole id; a `vendor/model`
  gateway names the vendor as publisher, and a flat gateway
  (`FLAT_ID_GATEWAYS`: Zen `opencode/…`, Go `opencode-go/…`, Copilot) takes it
  from the model id's reviewed family (`inferModelPublisher`: `claude-` is
  Anthropic, `gpt-` OpenAI, `glm-` Z.ai, …; an unreviewed family keeps the
  gateway, which only makes review independence stricter).
  Google Antigravity offers Gemini ids with a thinking level
  (`gemini-3.8-flash-high`, `gemini-3.1-pro-low`): always `google`, the level
  dropped (unless the catalogue knows the whole id) and reported as `effort`;
  facts are the Gemini API's, with the `-preview` release standing in for an
  id Google serves only as one (`gemini-3.1-pro`); anything but a Gemini id is
  unrecognised.
  A signed identity overrides the rule. `orderKnownFirst` ranks known first.
- **Tier (KM3).** `assessModelCapabilityTier` takes the frozen reviewed
  registry first, otherwise `autoCapabilityTier` from catalogue facts
  (reasoning, context, output price band, status), recorded as `auto` with
  `AUTO_TIER_RULE_VERSION`. A low-confidence auto tier counts one tier lower
  (`floorTier`, `meetsCapabilityFloor`). `catalogueFloorTier` is the hook
  `resolveExecutionRouteManifest({ classifyUnreviewed })` accepts, so a
  published manifest pins the auto tier like a reviewed one.
- **Billing (O7, O11).** `classifyAgentBilling({agentId, providerId,
  credential})` says whether a route is a `subscription` the person already
  pays for or `pay_per_use` on their own key or credit. It follows how the
  provider bills, not how it signed in: Claude Code and Codex are plans,
  DeepSeek Harness is its key; for OpenCode (pass the ROUTE provider)
  OpenCode Go, GitHub Copilot and GitLab are plans however signed in, ChatGPT,
  SuperGrok and Poe are plans when signed in and pay-per-use with a key,
  OpenCode Zen and every other key are pay-per-use. Google Antigravity is
  always Google: a Gemini Enterprise licence or a personal Google sign-in is a
  plan (pass the resolved `tier`; the Pay-as-you-go edition,
  `isGeminiEnterprisePayAsYouGoTier`, is pay-per-use), a Gemini API key is
  pay-per-use; `geminiEnterpriseCredentialLabel(tier)` names the credential
  ("Gemini Enterprise Plus"). `resolveAgentRouteBilling` trusts the
  connector's label for OpenCode and Antigravity, then the billing it put on
  the provider's ready credentials, then their kind. Unknown is pay-per-use:
  "your subscription" is claimed only when it is one. The connector labels a
  turn with `remoteMoneyBasisFor(kind)`; Auto ranks on it.
- **Price (KM4).** `resolveModelPrice` answers reviewed provider row, then
  "catalogue price", then unpriced; `blocksNativeWork` is always false.
  `estimateListPriceCostMicros(price, usage)` prices one turn's tokens at a
  catalogue list price in USD micros (undefined when unpriced, never free);
  `geminiListPriceUsage(usageMetadata)` splits Gemini's usage the way the list
  price charges it (cached input apart, thinking as output), and
  `listPriceSnapshotId(model)` names the catalogue revision and model an
  estimate used.
- **Auto (System One UC2, SO4b).** `planAutoRoutes({candidates, judgement})`
  picks the planner, executor and validator from the models a person's
  computer can run now. `autoMinimumTier(role, judgement)` reads the reviewed
  table `AUTO_EXECUTOR_TIER_POLICY` (`AUTO_ROUTE_POLICY_VERSION`
  `auto-route-v2`): the planner and validator are always `strong`; the
  executor's minimum comes from the task mode and effort (0-4), one tier up
  when the task is ambiguous, never below `minimumTierForRole`. Among the
  eligible models it prefers what the person already pays for (a candidate's
  `billing: 'subscription'`) before pay-per-use, then known, priced, active,
  then the lowest blended price (input 0.8, output 0.2), and keeps the
  executor's model distinct from the planner's and validator's. A candidate
  without `billing` ranks with pay-per-use, so a set that carries none ranks
  as v1 did. Without a judgement it uses
  `DEFAULT_AUTO_JUDGEMENT` (a moderate feature), so Auto works without
  System One.

A route records whose choice it is: the role configuration's `selection`
(`person` or `auto`) becomes the manifest route's `choice` when the role names
an `agentId`. Only a present `choice` is hashed, so a manifest from before
Auto keeps its hash; an `agentId` without a `choice` is the person's.

The catalogue authority (`catalogueModelAuthority(agentId)` on
`remote-instance-internal`) is the fixed, unsigned binding a runtime reports
an agent's offered values under when its release signed no mapping for that
agent; the snapshot's optional `offeredOptions` carry each value's name and
group.

### `events` — Event Topics & Payloads

Billing/credit event topic constants and typed payloads for inter-plugin communication via Backstage's event system.

### `leases` — Runtime License Leases

Signed runtime lease types (`RuntimeLicenseLease`, `RuntimeInstallType`) and the lease constants (`LEASE_ALG`, `LEASE_ISSUER`, `LEASE_AUDIENCE`) for issuer/verifier alignment without external schema dependencies.

### `permissions` — Permission Registration Contracts

`PermissionTier` enum, `PluginPermission`, and `PermissionRegistrationService` interface for plugin-to-platform permission registration.

### `routing` — Workload Routing Contracts

**Exports:**

| Export | Kind | Description |
|--------|------|-------------|
| `RepositoryProvider` | Type | `'github' \| 'gitea' \| 'gitlab'` |
| `RuntimeKind` | Type | `'managed' \| 'onprem'` |
| `ExecutionPreference` | Type | `'managed_only' \| 'onprem_preferred' \| 'onprem_required' \| 'hybrid_allowed'` |
| `VcsLocationHint` | Type | `'managed' \| 'onprem_only' \| 'any'` |
| `TaskRuntimeClassification` | Type | `'local_required' \| 'managed_allowed' \| 'same_runtime_required'` |
| `WorkloadRoutingRequest` | Interface | Request core's routing service evaluates |
| `WorkloadRoutingDecision` | Interface | Core's routing decision — persisted on the plan |
| `RepositoryProviderSchema` | ZodSchema | Runtime validation for `RepositoryProvider` |
| `RuntimeKindSchema` | ZodSchema | Runtime validation for `RuntimeKind` |
| `ExecutionPreferenceSchema` | ZodSchema | Runtime validation for `ExecutionPreference` |
| `VcsLocationHintSchema` | ZodSchema | Runtime validation for `VcsLocationHint` |
| `TaskRuntimeClassificationSchema` | ZodSchema | Runtime validation for `TaskRuntimeClassification` |
| `WorkloadRoutingRequestSchema` | ZodSchema | Runtime validation for `WorkloadRoutingRequest` |
| `WorkloadRoutingDecisionSchema` | ZodSchema | Runtime validation for `WorkloadRoutingDecision` |
| `NO_ELIGIBLE_RUNTIME` etc. | Const | Structured routing error codes |

Shared by core (routing authority), harness (plan_create MCP intake), and ai-agent-assistant (plan dispatch). Zod schemas enable runtime validation at trust boundaries across all consumers.

#### Pull-Based Dispatch Contracts

Pull-based dispatch moves plan intake from a push model to a pull model: the runtime polls for work assignments, claims them, executes, and reports results. All schemas are Zod-validated at trust boundaries.

| Export | Kind | Description |
|--------|------|-------------|
| `PlanStatus` | Type | `'pending' \| 'claimed' \| 'running' \| 'completed' \| 'failed'` |
| `PlanRepository` | Interface | Repo descriptor within a submitted plan |
| `PlanSubmissionPayload` | Interface | Plan submitted to the pull queue |
| `WorkAssignment` | Interface | Work assigned to a runtime on pull |
| `PullRequest` | Interface | Runtime polls with this request shape |
| `ClaimResult` | Interface | Runtime acknowledges claiming an assignment |
| `WorkReport` | Interface | Runtime reports execution outcome |
| `ReportAck` | Interface | Core acknowledges receipt of the report |
| `WorkTypeSchema` … `ReportAckSchema` | ZodSchema | One schema per interface for runtime validation |

### `session-harness-context` — Session-Threaded Harness Intake Context

**Exports:**

| Export | Kind | Description |
|--------|------|-------------|
| `SessionHarnessContext` | Interface | Harness-relevant context threaded into a session (all fields optional) |
| `SessionHarnessContextSchema` | ZodSchema | Runtime validation for `SessionHarnessContext` |
| `isSessionHarnessContext(value)` | Type guard | Delegates to `SessionHarnessContextSchema.safeParse()` |

Shared by the app (BFF), core, ai-agent-assistant, and harness. Injected into `session.meta` / `run.meta` at session intake and carried through plan_create MCP to core's routing engine.

### `runtime-config` — Runtime Config Registry

Single source of truth for every DB-canonical runtime tunable. Shared between harness (owner), core (control-plane management surface), and app (admin UI rendering). Exports `RUNTIME_CONFIG_REGISTRY`, `RuntimeConfig` type, and lookup helpers.

### `secret-refs` — Logical Secret Ref Primitives

Parser, validator, and redaction model for logical secret references shared across core, agent-harness, agent-assistant, and app. Avoids each plugin maintaining a slightly different `mount/path#key` parser.

**Exports:**

| Export | Kind | Description |
|--------|------|-------------|
| `LogicalSecretRef` | Type | `` `${string}/${string}#${string}` `` — canonical shape: `mount/cluster/plugin/tenant/key#field` |
| `SecretBindingReference` | Interface | `{ cluster, plugin, tenant, key, field? }` — structured Vault path reference |
| `CLUSTER_RE`, `PLUGIN_RE`, `TENANT_RE`, `KEY_RE` | RegExp | Segment validation regexes (ported from `@konteks/plugin-secret`) |
| `LOGICAL_SECRET_REF_SEGMENT_COUNT` | `5` | Expected `/`-separated path segments before `#` |
| `MASKED_KEY_REPLACEMENT` | `"***"` | Replacement string for key masking |
| `validateLogicalSecretRef(value)` | Function | Throws `TypeError` on malformed/env-style refs |
| `vaultPathToLogicalRef(vaultPath, field?, mountPath?)` | Function | KV v2 path → logical ref conversion |
| `logicalRefToSecretBinding(ref)` | Function | Parse logical ref → structured binding |
| `maskSecretRef(ref)` | Function | Replace key segment with `***` for logs/UI |
| `logicalSecretRef()` | Function | Zod schema wrapping `validateLogicalSecretRef` — validates a `LogicalSecretRef` inline in a larger contract (shape-only, never resolves the secret). Failures surface as Zod issues, so `safeParse` returns `success:false` instead of throwing. |

**Usage:**

```ts
import {
  validateLogicalSecretRef,
  vaultPathToLogicalRef,
  logicalRefToSecretBinding,
  maskSecretRef,
} from '@konteks/backstage-plugin-common';

// Convert a Vault KV v2 path to a logical ref
const ref = vaultPathToLogicalRef(
  'secret/data/prod/mcp/acme/api-key',
  'token',
);
// => "secret/prod/mcp/acme/api-key#token"

// Validate at trust boundaries
const validated = validateLogicalSecretRef(ref);

// Parse to structured binding
const binding = logicalRefToSecretBinding(validated);
// => { cluster: 'prod', plugin: 'mcp', tenant: 'acme', key: 'api-key', field: 'token' }

// Mask for safe logging
maskSecretRef(ref);
// => "secret/prod/mcp/acme/***#token"
```

**Path convention:** Assumes HashiCorp Vault KV v2 paths (`{mount}/data/{cluster}/{plugin}/{tenant}/{key}`). The `/data/` segment is stripped during conversion. Default mount path is `"secret"`; override via the optional `mountPath` parameter.

**`field?` semantics:** The `field` property on `SecretBindingReference` identifies a specific key within the resolved secret object. **Field extraction is a caller responsibility** — this package parses and round-trips `field` but does not resolve secret values.

### `billing` — Canonical Monetization Contracts

Shared Story Point, quote, reservation, entitlement, BYOK provider-cost, and usage-event contracts so `core`, `ai-agent-assistant`, `ai-agent-harness`, and `app` speak one billing language. This layer owns the **unit system and wire shapes**, never pricing policy or balance state — those remain in `core`. All exports are re-exported from the package root (`@konteks/backstage-plugin-common`).

| Module | Exports | Description |
|--------|---------|-------------|
| `billing/story-points` | `StoryPointAmountSchema`, `storyPointsToMeteringUnits`, `meteringUnitsToStoryPointAmount`, `formatStoryPoints`, `METERING_UNITS_PER_STORY_POINT`, `REVERSAL_EVENT_TYPES` | Canonical Story Point amount + integer-backed conversion (1 SP = 1000 metering units; 0.001 SP = 1 unit). Rejects negative usage unless a reversal/refund/release/correction event type is supplied. Formatter: 2-decimal display, 3-decimal export. |
| `billing/money` | `MoneyAmountSchema`, `CurrencyCodeSchema` | ISO 4217 currency + integer minor units. No implicit decimal assumptions. |
| `billing/plans` | `PLAN_IDS`, `PlanIdSchema`, `PlanSchema` | Canonical plan ids `free`/`builder`/`team`/`scale`/`enterprise` + shared plan shape. |
| `billing/entitlements` | `EntitlementsSchema` | Typed plan gates (Free→Enterprise): limits and feature flags. |
| `billing/meters` | `METER_CATALOG`, `METER_IDS`, `MeterIdSchema`, `MeterDefinitionSchema`, `getMeterDefinition` | Stable meter ids across free/chat/planning/MCP/harness/runtime/validation/failure with per-meter metadata (chargeability, pricing basis, quote/auth/idempotency requirements). Ids only, not the price table. |
| `billing/quote` | `QuoteRequestSchema`, `QuoteResponseSchema`, `QuoteDimensionsSchema`, `QuoteLineItemSchema` | Quote request/response with line items, Story Point totals, budget/approval flags, cheaper modes. External provider estimate is kept **separate** from Story Point totals. |
| `billing/reservations` | `AuthorizationRequestSchema`, `AuthorizationResponseSchema`, `ReservationMetadataSchema` | Authorize/reserve/commit/release/reverse contracts. UUID reservation ids; strict metadata rejects truthy-but-invalid billing metadata. |
| `billing/provider-cost` | `ProviderTypeSchema`, `ExternalProviderCostEstimateSchema`, `ProviderSpendThresholdSchema`, `ProviderSpendThresholdSetSchema`, `ProviderSpendObservationSchema` | Provider category + external cost estimate + provider-spend **warning threshold** (currency + positive integer minor units), its canonical per-currency **set** (`ProviderSpendThresholdSet` — at most one threshold per currency), and the observed-spend shape. All provider money — currency-tagged, compared same-currency only (no FX), never folded into Story Point totals. |
| `billing/usage-events` | `UsageEventSchema`, `USAGE_EVENT_TYPES`, `ProviderUsageSchema`, `BatchUsageEventPayloadSchema`, `BatchEventResultSchema`, `BatchUsageEventResponseSchema` | One usage-event envelope covering quote/reservation/work/failure/PR/review/merge/runtime/validation/provider/catalog events, plus the canonical batch `{ events: UsageEvent[] }` contract with per-event ingestion results. |

**Usage:**

```ts
import {
  storyPointsToMeteringUnits,
  meteringUnitsToStoryPointAmount,
  QuoteResponseSchema,
} from '@konteks/backstage-plugin-common';

// Always do math in integer metering units, never on the decimal string.
const units = storyPointsToMeteringUnits('1.25'); // => 1250
const amount = meteringUnitsToStoryPointAmount(units); // { unit: 'story_points', storyPoints: '1.25', meteringUnits: 1250, precision: 2 }

// Refunds require an explicit reversal event type.
storyPointsToMeteringUnits('-1', { eventType: 'refund' }); // => -1000

// Validate a quote at the trust boundary.
const quote = QuoteResponseSchema.parse(payload);
```

### `lifecycle` — Governed Delivery Contracts

Prompt identity, capability tiers, execution profiles, quote assumptions, budget envelopes, delivery authority, and lifecycle invocations. Two invariants in this layer are worth stating at the README level because getting either wrong fails silently and late.

**A delivery is classified under the policy it pinned, never the current one.** `ResolvedExecutionRouteManifest` records the `capabilityPolicyVersion` its routes were resolved under, and `ExecutionProfileRef` carries that version onward — it is the one object that reaches quote assumptions, the approved authority, the budget envelope, and every invocation. Copy the version from the manifest rather than assembling it, and classify under the ref's `capabilityPolicyVersion`; a legacy ref that pins none must be resolved by re-reading the stored manifest, **never** by falling back to `MODEL_CAPABILITY_POLICY_VERSION`. `AuthorizedDeliveryBudgetEnvelopeSchema` rejects an envelope whose per-route `capabilityPolicyVersion` disagrees with its own pinned ref — that disagreement is precisely the symptom of a producer reading the global default.

**The executor names a unit; the envelope prices it.** An envelope carries `schemaVersion: 'authorized-budget-envelope-v2'` and `unitReservations` — the authoritative schedule of every bounded unit the approved lifecycle may admit, each priced from the quote's pinned price snapshot. The executing service sends the unit's identity (`routeId?`, `lifecycleRole`, `unitKind`, `meterId`) and `resolveUnitReservation()` answers with the amount; `BudgetAdmissionRequest` carries **no** `reserveMeteringUnits` for a caller to propose. A unit absent from the schedule is denied `unit_not_scheduled` — there is no default reserve to fall back on, and a `0` reserve is a real quoted price (a free meter, or a sub-unit whose parent carries the charge), never a stand-in for "unpriced".

A unit's identity is the tuple `(routeId, lifecycleRole, unitKind, meterId)` — `reserveMeteringUnits` is the price that tuple resolves to, never part of it — and an absent `routeId` is its own identity value rather than a wildcard, so a caller cannot keep a quoted meter while changing the route or role it runs under. `AuthorizedDeliveryBudgetEnvelopeSchema` rejects a duplicated identity (two prices for one unit would make the charge depend on array order) and a scheduled unit naming a route the envelope does not quote.

**Reconciliation reports observations, not conclusions.** `BudgetReconciliationRequest` carries `observedMeters` — meter ids and quantities. It deliberately has no `actualMeteringUnits`: pricing a quantity needs the pinned price snapshot the caller does not hold, so an actual sent from outside would be the same unverifiable number the schedule exists to eliminate, arriving where nothing is left to check it. Core prices the observation and `computeReconciliation()` returns the authoritative actual with the resulting balances. Exceeding the *reservation* is ordinary variance and settles as `reconciled`; exceeding the *authorized maximum* returns the distinct `overrun` status with what was clamped, because that is an approval-boundary event and folding it into a clean settlement would hide it. Where that conversion has not run, `storyPoints.consumedMeteringUnits` reflects conservative settlement at the reserved amount and must not be presented as actual spend.

```ts
import {
  classifyModelCapabilityTier,
  resolveUnitReservation,
  checkAdmission,
  computeReconciliation,
} from '@konteks/backstage-plugin-common';

// Classify under what the artifact pinned — not what is current.
const tier = classifyModelCapabilityTier(model, manifest.capabilityPolicyVersion);

// Name the unit; the envelope answers with the approved price.
const resolved = resolveUnitReservation({
  envelope,
  requested: { routeId, lifecycleRole, unitKind, meterId },
});
if (!resolved.resolved) throw new Error(resolved.message); // unit_not_scheduled | route_not_quoted

// Commercial identity is settled; now check it fits remaining authority.
const remaining = checkAdmission(envelope, resolved.reserveMeteringUnits);

// On completion: report what was observed, let Core price it.
const settlement = computeReconciliation({
  envelope,
  admissionId,
  heldMeteringUnits: resolved.reserveMeteringUnits,
  actualMeteringUnits, // priced by Core from `observedMeters`
});
```

#### Delivery transcript notices

The decision boundaries Core reports into a session's conversation: a quote
offered, approved, revised, or closed; a framed question asked or answered; a
plan confirmed, rejected, or sent back for re-planning. Reason, stage, and
outcome enums are references to the delivery contracts that already name those
facts, never re-declarations.

### `catalog-learning` — Review Proposals, Discovery Handoff, Structure

Wire contracts for the catalog review loop. Every field is either **evidence-backed** (`proposedValue` + at least one `evidenceRefs` entry + a `low`/`medium`/`high` confidence) or an explicit **question** (`requiresHumanValue`, no value, no field evidence, confidence `none`). There is no third shape, so nothing can reach the catalog without either citing evidence or asking a human.

| Export | Description |
|--------|-------------|
| `CatalogLearningProposalInputSchema`, `CatalogLearningProposalSchema`, `CatalogLearningProposalFieldSchema` | The durable review document and its fields. Field names are unique per proposal and every `evidenceRefs` entry must exist in the proposal's `evidence`. |
| `CatalogLearningProvenanceSchema` | Which signal family a suggestion came from — `catalog-descriptor`, `codeowners`, `manifest`, `framework-marker`, `release-signal`, `workspace-layout`. Optional on evidence-backed fields, so producers written before the inference ladder keep validating. |
| `CatalogLearningEvidenceKindSchema` | Citable evidence kinds, including `codeowners`, `manifest` and `release-signal`. |
| `CatalogDiscoveryHandoffSchema` | Tenant- and repository-scoped handoff from the Onboard scanner to Core. Carries suggestions **and** questions (max 3 fields, `alias` forbidden in either form) so Core never has to guess which silence meant "no signal". A question may carry `displaySignal` — the raw signal that prompted it, such as an unmapped CODEOWNERS handle. An `owner` suggestion's value must be a Group entity ref; a raw VCS handle is rejected. Optional `structure` and `dependencies` carry a shape suggestion and Component→Component dependency suggestions; both are absent on a field-only handoff, so every producer written before them keeps validating. |
| `CatalogGroupSummarySchema` | Read projection of the tenant Groups offered as owners. `isTenantFallback` marks the tenant-wide placeholder bootstrapped Components start on, so it can be offered without being mistaken for a real team. |
| `CatalogLearningReviewTargetSchema` | The Component read model. `ownerRef` exposes the current owner as a typed reference, or `null` when the stored owner is not a well-formed entity ref — never a reference invented from free text. |
| `CatalogLearningRevisionSchema`, `CatalogLearningRevisionChangeSchema`, `CatalogLearningRevisionOutcomeSchema` | The applied revision. Each change may record an `outcome` — `accepted`, `overridden`, `skipped`, or `answered` — as calibration telemetry. `answered` is separate from `accepted` because a field the scanner refused to guess carries no suggestion, so folding the two together would misreport the scanner's accuracy. The taxonomy mirrors the field contract's own split: `accepted` and `overridden` require a `proposedValue`, `answered` forbids one, and `skipped` is free either way — so acceptance rate can only be measured over fields where a suggestion existed. Optional, so revisions applied earlier still read back. |
| `CatalogStructureProposalInputSchema`, `CatalogStructureProposalOriginSchema` | A proposal to change the catalog's shape rather than a Component's fields: a `split` has exactly one source and at least two results, a `merge` at least two sources and exactly one result. Reachable from the handoff's optional `structure`. Each proposed Component's `repositoryRefs` is advisory input: the catalog owner rewrites it from the repositories it resolved for the bound Component, because repository entity identity is the catalog owner's to derive and a producer's replica of that naming can drift. `origin` says who asked: absent or `scanner` is the inferred proposal every producer already writes and must cite at least one evidence entry; `human` is a reviewer's own assertion, which carries **no** evidence at all and a `rationale` instead. A `human` proposal may only be a `merge` — a split is read out of a repository, so a hand-made one could cite nothing. |
| `CatalogStructureApplyInputSchema`, `CatalogStructureCorrectionSchema` | Accepting a structure proposal. `corrections` lets the reviewer fix the shape before it becomes real — rename a proposed Component, re-point its `sourcePath` (`null` clears it), or `drop` it — addressed by the name the proposal gave it. Corrections are strict objects so a mis-keyed one fails instead of being discarded, and the corrected result is re-validated against the structure rules, so a correction can never yield a split of one or a merge of several. An apply carrying no corrections applies exactly the proposed shape. |
| `CatalogStructureMergeRequestSchema` | A human asking for a merge: the source Components (at least two, no duplicates) and what the result should be called. `kind` is an enum rather than a literal so a `split` is refused with the reason instead of a shape error. The request names no repositories — repository identity is the catalog owner's, derived from the sources it resolves itself. |
| `CatalogLearningContinuitySchema`, `CatalogLearningRevisionStructureSchema` | Identity descent for an accepted structure change. Required whenever a revision carries `structure`, so a retired Component stays resolvable instead of stranding every reference to it. |
| `CatalogComponentDependencyEdgeInputSchema` | A suggested dependency from the Component under review onto another Component. The review field vocabulary describes one Component's own attributes and cannot express a relationship, so an edge is its own kind of suggestion. It names only its **target**: the source is the Component the review is about, and the object is strict so a producer that tries to name a source is refused with the reason rather than silently ignored. Cited `evidenceRefs` must resolve to evidence carried in the same message; a manifest-derived edge is `medium`, because a declared build dependency is a real signal but not proof of a runtime relationship. Reachable from the handoff's optional `dependencies` and persisted on the proposal, where the container refuses a self-edge and a duplicate target. |
| `CatalogComponentDependencyDecisionSchema`, `CatalogLearningRevisionDependencySchema` | A human's verdict on one suggested edge (`accept` or `reject` — an edge carries no value to correct) and how the revision records it. The outcome reuses the field vocabulary rather than a parallel one: an accepted edge is `accepted`, a rejected one `skipped`; `overridden` and `answered` cannot occur and the schema refuses them. `CatalogLearningApplyInputSchema.dependencyDecisions` carries the verdicts and rejects two decisions for the same target; an apply may now decide only edges, but one that decides nothing at all is still refused. Both the proposal's `dependencies` and the revision's are optional, so reviews and revisions written before edges existed read back unchanged. |
| `CatalogSystemGraphSchema` (node and edge schemas are internal) | A tenant's read-only view of one System's shape: `system`/`component`/`repository` nodes and `partOf`/`dependsOn`/`componentDependsOn` edges. The graph is **closed** — every edge endpoint is declared as a node — and node refs are unique, so a renderer never invents a placeholder for a target it cannot see. A node's `type`/`lifecycle`/`ownerRef`/`reviewState` are omitted when the catalog holds none rather than defaulted. Edge `provenance` separates a structural `catalog` fact from an `accepted-revision` relationship a human installed; a dependency between Components is only ever the latter, so a System with no accepted edge has none. A Component a structure revision retired is not part of the live shape. |

### `natural-learning` — Context Check, Natural Reference, Session Scope

Canonical wire schemas for the natural learning loop, layered on the `catalog-learning` primitives (field states, confidence, review field names, repository provider, evidence). Every object schema is `.strict()`; all shapes are read models or human-confirmed inputs and carry no implicit apply/confirm authority.

| Export | Description |
|--------|-------------|
| `CatalogContextCheckSchema` (+ `CatalogContextCheckKnownFactSchema`, `...SuggestedFactSchema`, `...QuestionSchema`, `...QuestionInputSchema`, `...FactSourceSchema`) | Context-check presentation read model. Known facts are read-only and carry provenance; suggestions must cite evidence and a reason; questions carry a prompt/reason/consequence and **no** evidence or confidence. Invariants: known-fact fields are never re-asked or re-suggested, question fields are unique, the displayed adaptive set is capped at 3 with `remainingQuestionCount`. |
| Review context on the context check | A suggestion may carry `provenance` (`CatalogLearningProvenanceSchema`) naming the signal family its value was inferred from, beside the evidence refs that say where it came from. A question may carry `displaySignal` — the raw signal that prompted it, such as an unmapped CODEOWNERS handle — quoted back as observed context. `displaySignal` is not evidence: it carries no confidence, cites nothing, and is not a value the human can accept, so a question carrying one is still rejected if it also carries `evidenceRefs`, `confidence`, or `proposedValue`. Both are optional and live on opposite sides — a question has no inference to attribute, a suggestion has no unarbitrated signal — so `.strict()` rejects each on the other. |
| `CatalogContextCheckSavedAnswerSchema`, `CatalogContextCheckProgressSchema` | Saved human answers (`accept`/`edit`/`skip`/`defer`; `editedValue` iff `edit`) and saved progress (always `status: "pending"`, user-attributed, unique per field, bound to review/proposal/version). |
| `CatalogContextCheckPreviewSchema`, `CatalogContextCheckPreviewEntrySchema` | Apply preview. Only accept/edit can yield a `verified` state; skipped/deferred values remain non-verified. |
| `NaturalReferenceQuerySchema` | Free-text lookup scoped to a App system UUID (tenant/actor come from auth, never the wire), with an optional `lockedScope` hint for in-session amendment classification. |
| `NaturalReferenceResolutionSchema` (+ `NaturalReferenceCandidateSchema`, `NaturalReferenceCrossSystemConflictSchema`) | Read-only resolution outcome: `none` (optionally `no-candidate`/`incomplete-association`), `unique` (candidate must match the proposed scope), `ambiguous` (≥2 candidates), `cross-system` (safe-disclosure conflict only), `locked-scope-amendment` (deduplicated additional repositories + fresh-quote flag). |
| `ProposedSessionScopeSchema`, `ProposedSessionScopeRepositorySchema` | Complete, provider-valid session scope: non-empty deduplicated repositories, all matching the scope's `repositoryProvider`. |

`CatalogLearningApplyInputSchema` additionally accepts an optional `expectedProposalVersion` stale-version guard (additive; old writers omit it).

### `collaboration` — the social plane and the Bridge

Canonical contracts for the collaboration surface (collaboration-mode CP1). Every schema is `.strict()`. Reads carry `CollaborationVoiceSchema` objects (`person`/`agent`/`platform`) while writes carry refs; there is deliberately no Issue aggregate — severity, status and assignment stay with the `ops` service, and an activity subject may only carry a **read-time display copy** of them. Published conformance fixtures live in `fixtures/collaboration/` and are reachable as `@konteks/backstage-plugin-common/fixtures/collaboration/*`.

| Export | Description |
|--------|-------------|
| `CollaborationVoiceSchema`, `CollaborationVoiceKindSchema` | Who is speaking: a person, the agent, or the platform. A person voice may carry a resolved `picture`. |
| `InitiativeSchema` (+ `InitiativeCreateInputSchema`, `CollaboratorRefInputSchema`) | A human-led unit of vision: server-derived `phase` (`planning`/`executing`/`validating`), nullable `pmSessionId`, `setup {state, error?, updatedAt}`, `acceptance {by, at} \| null`, `validation {qa, runRef?, at?}` where `blocked` is its own word, and a `revision`. The create carries `{systemId, title, attachments? ≤4}`. |
| `NoteSchema`, `ThreadPostSchema`, `ThreadSchema`, `ThreadSubjectKindSchema`, `threadSubject()` | Notes on an initiative and generic threads whose subject is `<kind>:<opaqueId>` over `note · incident · release · initiative · ticket · activity`. Reactions and comment counts hang off both; there is no separate `CommentSchema`. |
| `ReactionSummarySchema`, `ReactionInputSchema` | The closed reaction set `👍 ❤️ 👀 🚀 ⚠️`, unique per (subject, actor, emoji). |
| `AttachmentRefSchema` | A ref to the existing tenant-file infra — never content. |
| `ReleaseSchema` (+ `ReleaseTotalsSchema`, `ShipReleaseInputSchema`, `ReleaseProposalSchema`) | A release candidate/band: `version` is `null` while candidate, `componentRefs` leads the row, `memberSummaries` carry each member's phase and driver, and totals carry `settledStoryPoints` (every settled delivery of every member ticket, counted in the optional `settledDeliveries`) plus `CollaborationMoney[]` with `coverage`. One open candidate per (tenant, System). |
| `CollaborationMoneySchema`, `collaborationMoneyFromMicros()` | `MoneyAmount` (minor units) plus `coverage: complete \| partial \| unavailable`; the one micros→minor-units conversion, half-up and per currency. |
| `NotificationItemSchema`, `notificationItemIdFor()` | A bell item keyed `notif:<sourceEventId>:<userRef>`, carrying the service-rendered `body`, the subject ref and the actors. |
| `ActivityPostSchema`, `activityIdFor()` | A turning point in the timeline. `id` is opaque and derived from the source event (never prefixed, so its thread is `activity:<id>`); `kind` is open; `subject` names what it concerns and that record's state at read time. |
| `InvolvementStatSchema`, `ModelValueRowSchema`, `MenuCountsSchema`, paged envelopes | Leaderboard and attention reads. Envelopes are named per resource (`{initiatives}`, `{activities}`, …) with optional `nextCursor`/`total`; every count key is optional and absent is never 0. |
| `CollaborationEventSchema` (+ `collaborationEventId()`) | Collaboration → Core, discriminated on `type` (initiative/note/thread/reaction/attachment/release/notification/`subject.erased`), with deterministic `collab:<type>:<subjectId>:<revision>` ids. `notification.requested` carries the already-fanned-out per-user items; `subject.erased` names either the subject or the exact `sourceEventIds` a redaction removes. |
| `CollaborationFactEnvelopeSchema` (+ `CollaborationFactSubjectSchema`, `COLLABORATION_FACT_PAYLOAD_SCHEMAS`, `COLLABORATION_FACT_SUBJECT_BY_KIND`) | Core → collaboration. The outer `kind` is an open string (an unknown kind advances the cursor), while a known kind's payload is validated `.strict()`; `fact.tombstone` advances with no projection. |
| `collaborationFactIdFor()`, `collaborationProducerEventIdFor()`, `collaborationFactSequenceOutcome()` | The tenant-qualified `fact:<sha256>` id, the stable pre-allocation producer identity, and the contiguous-stream rule (`duplicate` / `applied` / `gap`). |
| `DiscussionReadSchema` | The agent's gated read: exactly one of `initiativeId`/`incidentRef`, attributed posts verbatim, and a per-note reaction/comment signal. |
| `CollaborationWakeRequestSchema`, `CollaborationNoticeRequestSchema` (+ `collaborationNoticeId()`) | The shared wake entry's PM body (platform-voiced, delegation-bound, never a user message) and the four notice kinds a conversation accepts. |
| `COLLABORATION_WAKE_TRIGGER_KINDS`, `collaborationWakeTriggerKind()`, `LINKED_ITEM_WAKE_EVENT` | What woke the planning session: `discussion`, or `linked_item` when a followed external item changed (Stage 1b, event `integration.source_changed`). The linked item's text never rides the trigger. |
| `InitiativeSchema.mergePolicy` | Who merges the initiative's tickets, chosen once at breakdown acceptance: `person` (default; absent reads as it) or `on_qa_accept`. Also rides `pm.breakdown_accepted`. |
| `DeliveryMergedFactSchema`, `DeliveryMergeFailedFactSchema` | Facts `delivery.merged` (ticket `merged`, merge SHA, who merged) and `delivery.merge_failed` (stable reason code; the ticket stays `delivered`), owner `initiative`. Collaboration ticket states are `open · delivered · merged · cancelled`. |
| `delivery.merge_requested` event | A person's Merge on a ticket, the one bridge event that may start a merge; a refusal returns as `delivery.merge_failed`. |

### `delivery-merge` — merging a delivered ticket

The harness is the only thing that touches Git; no agent merges, pushes or reviews.

| Export | Description |
|--------|-------------|
| `InitiativeMergePolicySchema`, `DeliveryMergeStrategySchema`, `mergeStrategyForPolicy()` | `person` → `manual`, `on_qa_accept` → `auto_on_ci`. `auto_after_timeout` is never offered from an initiative. |
| `DeliveryMergedBySchema` | `person {ref}` or `policy {onBehalfOf?}` (PM fills in the acceptor). |
| `DeliveryMergeFailureReasonSchema` | Stable codes: refusals before queuing (`qa_not_accepted`, `delivery_not_settled`, `no_pull_request`, …) and merge-run findings (`blocking_reviews`, `checks_failing`, `merge_conflict`, …). |
| `DeliveryMergeRequestSchema` | Core → harness: a person's merge of a plan, the one input that overrides `manual`. |
| `DeliveryMergeReportSchema`, `deliveryMergeReportId()` | Harness → Core, one per pull request: `merged` (SHA, when, by whom, stacked PRs retargeted) or `merge_failed` (reason code, blocking reviews, CI state), correlated by plan, task, session and proposal. The id is keyed by pull request and merge SHA, so a replay converges. |

### Project management: ticket order

`PmTicketStatusSchema` has `blocked` (derived on read by `pmTicketDerivedStatus()`/`pmTicketWaitingOn()`: a startable ticket whose dependency is not `merged` and that was not started stacked; never stored) and `merged` (set only by the `merge` echo, `PmFlowbackMergeSchema`). A ticket carries optional `startMode` (`wait` | `stacked`), `baseline {ticketRef, branch}` (stacked only) and `autoStart` (the one automatic start, or `auto_start_failed` with a reason). `PmBreakdownSchema` refuses a dependency graph with an unknown, self, repeated or cyclic ref; `pmTicketGraphIssues()` names the ticket and ref. `PmTicketSpawnRequestSchema` carries `startMode`, `PmSpawnActorSchema` says a person or Konteks (on behalf of the acceptor) started it, and the session ticket snapshot carries the `baseline`. The ticket session correlation also carries `mergePolicy` (Core reads it at activation), a delivery keeps its last failed merge as `mergeFailure` until the next merge, `autoStart.onBehalfOf` names the acceptor, and `pm.ticket_updated` (event and fact) carries `startedBy` and `ticketRef`.

### `remote-instance` — Runtime view (the runtime page)

A runtime is a place a person opens from the left menu. These public shapes
carry what that page shows; every heartbeat and view field is optional, so a
connector or Core released before them keeps parsing (the App then asks the
person to update the computer).

| Export | Description |
|--------|-------------|
| `REMOTE_WORK_KINDS` … `'direct'`, `DIRECT_WORK_KIND`, `isDirectWorkKind()` | A direct session's prompt: a plain chat with the person's own agent on one runtime (role `assistant`). Not a conversation kind: it carries its own `direct_session` source (`ownerInstanceId`, `sessionId`, `turnRef`, `acpSessionRef?`), instance-bound to the runtime it started on. |
| `AvailableCommandSchema`, `AvailableCommandListSchema`, `normalizeAvailableCommands()` | The slash commands an agent announced on this computer (`availableCommands` + `availableCommandsLearntAt` on a connected agent). Names carry no slash; at most 128 per agent. The normalizer turns an ACP `available_commands_update` into a list the schema accepts, minus refused names. |
| `SUPPORTED_AGENT_STATES`, `SupportedAgentEntrySchema`, `SupportedAgentListSchema` | Every supported agent's real state on the computer (`supportedAgents` on the heartbeat and the instance view), with the version found, the supported range and the install commands. |
| `RuntimeSessionsPageSchema`, `RuntimeSessionEntrySchema`, `RuntimeSessionsQuerySchema`, `runtimeSessionKindForWorkKind()` | The viewer's own sessions on a runtime, 10 at a time, plus `othersCount`. The instance view's `activeSessionCount` counts everyone's. |
| `DirectSessionStartRequestSchema`, `DirectSessionPromptRequestSchema`, `DirectSessionViewSchema`, `DirectSessionUsageSchema`, `DirectSessionEventSchema`, `DirectSessionEventsPageSchema` | Start (agent, optional model), prompt (bounded multi-line text), the session (state, why it ended, usage: a subscription shows tokens only) and its transcript and stream events. |
| `ConnectorCommandSchema`, `ConnectorCommandsManifestSchema`, `connectorCommandsFor()` | The `konteks-remote` commands a connector release ships in `commands.json`, per system; the connector reports the manifest as `connectorCommands` on the heartbeat (first heartbeat of each process and on change) and the instance view carries the latest. |

Authorization adds `runtime_sessions_list`, `direct_session_start` (`execute`
alone; never another person's personal runtime), `direct_session_steer` (the
session's owner) and `direct_session_read` (the owner or an auditor); audit
adds `direct_session_started`, `direct_session_prompted`,
`direct_session_cancelled` and `direct_session_ended`.

### `agent-integration` — External integrations through the person's own agent

`@konteks/backstage-plugin-common/agent-integration` (also re-exported from the
root). Shared by App, Core and the native runtime so a provider link, an
operation, a record state and a status label mean one thing everywhere.

| Export | Description |
|--------|-------------|
| `INTEGRATION_PROVIDERS`, `parseProviderLink()`, `displayProviderKey()`, `defaultProviderOperations()` | Eight providers: `jira`, `slack`, `teams`, `asana` (contract scope) and `github`, `linear`, `notion`, `figma` (planned, read-only). `parseProviderLink(url)` is pure: it recognizes Jira (`/browse/KEY-1`, `/jira/.../issues/KEY-1`, `selectedIssue=`), Slack (`/archives/C…/p…`, `thread_ts`), Teams (`/l/message/…`, `/l/channel/…`), Asana (`/0/<project>/<task>`, `/1/<ws>/project/<p>/task/<t>`), GitHub issues, Linear issues, Notion pages and Figma files, and returns `null` for everything else. It never fetches or invents a title. |
| `INTEGRATION_OPERATIONS`, `MODE_OPERATION_ALLOWLIST`, `checkModeOperation()` | Nine operation kinds with owner (`core` or `project_management`) and read/write class, and the allowlist for the five modes. A write never passes without an owner-held action id. |
| `IntegrationInvocationSchema`, `ExternalActionSchema`, `ExternalActionDecisionSchema`, `ExternalActionAttemptSchema`, `ExternalExecutionEvidenceSchema`, `ConnectionSetupOperationSchema`, `LinkedSourceFollowGrantSchema`, `LinkedSourceCursorSchema`, `ExternalUpdateRuleSchema` | Strict, versioned (`schemaVersion: 1`) records. People are `PersonRefSchema` (Core's entity ref `user:default/ana` or an opaque id, never a path). Provider account identity with site and subject, per-provider immutable object identity (`ExternalObjectIdentitySchema`), `EvidenceClass` as an enum (provider classes need an adapter signature), exact-human or standing-rule action authority. |
| `BINDING_STATE_TRANSITIONS`, `ACTION_STATE_TRANSITIONS`, `canTransition*()` | Allowed transitions as data. After a possible dispatch an action never returns to `queued` except from `confirmed_not_applied`. |
| `INTEGRATION_ERROR_CODES`, `INTEGRATION_ERROR_DEFINITIONS`, `integrationError()` | Stable errors with a fixed retry class (`none`, `after_user_action`, `automatic`, `reconcile_first`) and next action. |
| `IntegrationTaskSpecSchema`, `IntegrationTaskResultSchema`, `canonicalArgs()`, `argsDigest()`, `checkIntegrationToolCall()` | The Core to runtime integration task. Read, probe, verify and discover never grant a write; a write task admits exactly one tool and the exact canonical arguments. `canonicalArgs` sorts keys and rejects non-JSON values; `argsDigest` is its sha256. |
| `IntegrationFixtureServerSchema` (`fixtureServer` on a spec) | E2E only: a `fixture_mcp` binding may name a loopback HTTP MCP server (`127.0.0.1`, `localhost`, `[::1]`; no credentials in the URL) the runtime passes to the agent as an ACP `mcpServers` entry. A spec can never carry a command, and any other binding kind refuses the field. |
| `OFFICIAL_CONNECTION_SETUPS`, `officialConnectionSetup()`, `setupArgv()`, `setupCommandDigest()`, `IntegrationSetupTaskSpecSchema`, `IntegrationSetupResultSchema`, `IntegrationWorkloadSchema`, `integrationWorkloadDigest()` | Confirmed official setup (P08, D29). The reviewed catalogue pins a Codex command only where the vendor documents one (`codex mcp add <name> --url <url>`): Atlassian `https://mcp.atlassian.com/v2/mcp?tools=all`, Linear `https://mcp.linear.app/mcp`, Notion `https://mcp.notion.com/mcp`, Figma `https://mcp.figma.com/mcp`. Codex Slack and Asana (registered OAuth client) and GitHub (personal token) are typed handoffs to the vendor's instructions (`reason`); Teams has no Codex entry; every Claude provider is a handoff to `https://claude.ai/settings/connectors` (`account_connector`). Each entry supports `add`, `sign_in` and `remove` (`SETUP_CHANGES`); `setupArgv(entry, change)` derives `mcp add …`, `mcp login <name>` and `mcp remove <name>` from the entry, never from a task, and `setupCommandDigest(entry, change)` is sha256 of the canonical `{agentId, argv}` (an `add` keeps its old digest). A setup task (`kind: 'setup'`) names the change; a remove also says `addedByKonteks` (false only when the person confirmed removing an entry Konteks did not add). Its result is an outcome code (`added`, `already_present`, `signed_in`, `removed`, `absent`, `handoff`, `failed`), never command output. |
| `PROVIDER_ADAPTER_CATALOGUE`, `providerAdapterEntry()`, `FIXTURE_PROVIDERS`, `createFixtureWorld()`, `fixtureToolCall()` | The provider adapter catalogue and the synthetic provider spec in one file (`fixture-providers.ts`). Per provider and operation: the vendor catalogue, the identity tool, the tools a write's resolution probe, a read and a read-back call, and the write variants preferred first (`createOnly` with `forbiddenArgs` for a combined tool such as Jira v2 `addOrEditJiraIssueComment`, whose edit branch is never built). Certified: Jira issue comment, Slack thread reply, Teams channel reply and chat send (separately), Asana task comment, and `context.fetch` for all eight (GitHub, Linear, Notion and Figma have no write tool). Certification is `{fixture, live}`: `fixture_certified` where the CP11 synthetic MCP servers serve exactly these tools and shapes, `unproven` live everywhere. `fixtureToolCall(world, provider, tool, args)` is the response shape each synthetic server returns (it refuses unknown tools, the Jira edit branch and a Slack message without `thread_ts`, and records every call). |
| `SourceRefSchema`, `SourceRefLinkInputSchema`, `sourceRefFromLink()`, `providerResourceKey()`, `domainLinkExternalKey()` | Domain-owned references to an external item (CP6-CP9): `{provider, kind, key, canonicalUrl, observedAt?, observationRef?, linkedBy}`, always re-checked against its own link by `parseProviderLink` (a key on somebody else's URL is refused), never a title or fetched text. A write carries only `{url, observationRef?, observedAt?}`; the owner names `linkedBy` from authentication. `providerResourceKey` is Core's correlation key for a link; `domainLinkExternalKey` prefers the provider's immutable object id so a moved Jira key stays one link. |
| `TicketExternalLinkSchema`, `TicketExternalLinkCreateSchema`, `PM_TICKET_UNSUPPORTED_WORK_ITEM_OPERATIONS` | Project Management's ticket link to a Jira issue or Asana task (CP6): PM owns it with a revision Core edges cite. Work-item create and transition are recorded as unsupported until an adapter is certified. |
| `SourceNoticeSchema`, `ExternalUpdateNoticeSchema`, `IntegrationSessionNoticeSchema`, `SOURCE_NOTICE_EVENTS`, `EXTERNAL_UPDATE_NOTICE_LABELS`, `isSourceNoticeEvent()`, `isExternalUpdateNoticeEvent()` | The session notice payloads Core writes and the Assistant and App read: `source.linked` / `source.read` (invocation state, whether the item was captured) and `external_update.<label>` for the labels a person acts on (Approval, Posted/Created/Updated, Unchecked, Review, Failed, Cancelled; never Sending, Checking or Draft). Strict: provider, display key, canonical link of that provider and state only, never fetched text or update content; the label must be the event's and the state's own. |
| `IntegrationApprovalPolicySchema`, `ApprovalPolicyScopeSchema`, `scopedApprovalRequirement()` | The project-approval policy source: per workspace or per System, which write operations (optionally per provider) need an additional scoped approver. The credential owner's decision always stays required; a policy only adds an approver. |
| `FOLLOW_DEFAULTS`, `expectedFollowUsage()`, `FOLLOW_NOTICE`, `FOLLOW_STOP_REASONS` | Stage 1b following of linked items: the conservative cadence (15 min, unchanged checks back off to 6 h), per-item checks per day (24), per-initiative agent turns per day (48), lifetime (30 days), per-check context and tool-call caps (64 KiB, 4 calls), catch-up per computer (2 per sweep) Core uses unless its configuration narrows them; the expected-usage line; the one-time notice ("Konteks reads linked items again while your computer is online. It uses your plan."); why a follow is paused or stopped. |
| `EXTERNAL_UPDATE_TEMPLATES`, `externalUpdateTemplate()`, `renderExternalUpdateTemplate()`, `CreateUpdateRuleRequestSchema`, `StandingRuleRefSchema` | Stage 1b standing update rules. A rule names one versioned template (`delivery_update_with_links` r1: comments and replies, triggered by `delivery.settled`), rendered deterministically from the canonical fact only (pull request links, https, sorted, at most 10); never model prose, attachments, a new destination or a transition. `createRule: {template}` is the only input a person gives. A rule-based post names its rule (`standingRule {ruleId, ruleRevision}`) on the `external_update.*` notice and on `integration.update_posted`, so activity can show it with Revoke. |
| `connectionStatusLabel()`, `readStatusLabel()`, `writeStatusLabel()` | The closed dot-and-word labels. Read needs captured source; Posted (or Created/Updated) needs `confirmed`; an unknown outcome is never green. Copy has no em dash. |

Two collaboration fact kinds (`collaboration`) come from this feature, both on
the session's initiative stream through Core's relay:
`integration.source_linked` (an owner-supplied item was read into a session;
provider, resource kind, display key, correlation ref, no title or fetched
text) and `integration.update_posted` (an approved update was confirmed by a
matching read-back; provider, operation, display key, action ref, optional
result URL, never the content). Both optionally name the person
(`linkedBy`, `ownerRef`). A third, `pm.ticket_external_linked`, is Core's
projection of Project Management's producer fact of the same name (a ticket
was linked to an external work item: provider, kind, display key, link ref and
revision, who linked it; never the URL or a title).

Domain records carry the same references: `NoteSchema.sourceRefs` and
`ThreadPostSchema.sourceRefs` (writes take `sourceLinks`; `NoteSourceRefInputSchema`
adds one to a note), `QaFindingSchema.externalRefs` (Core-written, like
`ticketRef`; `QaFindingExternalRefInputSchema`), `QaCaseSchema.sourceRefs` (the
external criterion a case cites; never a result), and Ops' `source_linked`
timeline kind with `opsSourceTimelineRefs()` (`{provider, key, url}`) plus
`OpsIncidentSourceIntakeSchema` / `OpsIncidentSourceLinkSchema` (a person's own
title; no status field, so an external "resolved" cannot resolve an Incident).

The `integration` work kind lives in `remote-instance`: role `assistant`, not a
conversation kind, source `integration_task {ownerInstanceId, taskId,
specDigest}` (instance-bound), requires `integration-task-v1`
(`REMOTE_INTEGRATION_TASK_CAPABILITY`), and shares the role-binding exemption
with `direct` (`isRoleBindingExemptWorkKind`). A connector names it in
`acceptedKinds` only when `coreContractAtLeast(coreContractVersion,
REMOTE_INTEGRATION_MIN_CORE_CONTRACT_VERSION)` (`7.3`), exactly as `direct`
is gated at `7.1` (`REMOTE_DIRECT_MIN_CORE_CONTRACT_VERSION`).

## Development

### Native runtime authority (server only)

The `remote-instance-internal` entry exports strict runtime owner resolution,
process establishment, reconnect intent, flat recovery manifest, applied receipt
and relay registration/status/close contracts. These schemas grant no authority:
Core verifies the current process, lease, socket, recovery generation and actual
report history before accepting a request.

Use `RelayRuntimeHandshakeResultSchema` for a native socket and
`RelayHolderHandshakeResultSchema` for a viewer/controller socket. The former
requires recovery status; the latter forbids it. The generic handshake result
alone cannot validate socket context. Initial establishment requires HTTPS at
the Core owner; an accepted immutable intent may retain its establishment
precondition while retrying through a different authenticated transport.

The three `computeRemote*Digest` helpers parse their complete inputs before
hashing canonical semantic projections. Intent and applied-receipt identities
exclude fresh proofs and transport bindings. Manifest identity excludes the
renewable lease and advancing heartbeat counter projections, but retains its
original application deadline and every decision. Actual request signatures
still cover the full transport-bound request. Applied results are unique and
ordered by UTF-16 assignment ID then attempt. Schema-level terminal evidence
correlation is not verification of a durable report or its action's legality.

`relay_runtime` proofs admit only `register`, `status` and `close`, bind exactly
the instance path, retain the nested native handshake proof in the body digest,
and use their own relay-key nonce namespace. They do not authorize assignment
ingestion or acknowledgements.

### Hosted ACP continuity (server only)

`@konteks/backstage-plugin-common/remote-instance-internal` exports
`HostedChannelJournal` and its synchronous transaction callback port,
`HostedChannelTransactionPort`. Hosted Harness, Validation and Assistant can use
one protocol machine while retaining their own ORM and database ownership.
This module is absent from the public root and has no agent SDK dependency.

Each transaction locks one `(tenantId, sessionId, channelId)` record. The
adapter must commit the returned state atomically and roll back on any throw;
never await network I/O inside the callback. `adoptOwner` is local CAS fencing
after the caller verifies Core's committed ownership, not authority to take over.

`enqueue` journals a prompt and its replay frame together, rejecting changed
payloads under the same request ID. `acknowledge` accepts only owner-verified,
current-socket acknowledgements. `receive` preserves the inbound body and any
correlated terminal result before the wire receipt cursor advances. `consume`
advances a separate downstream cursor after idempotent domain/event persistence.
Completed request results survive grant succession and outbound acknowledgement.
At capacity or an unresolved replay age bound the journal stops; it never drops
unacknowledged or unconsumed work. Session retention/archival remains the owning
service's policy, not an automatic reset or indefinitely growing journal.

The owner still implements signed attach/replica proofs, immutable placement and
input checks, recovery, permission handling, request execution, and transport.
The continuity machine itself opens no connection and grants no permission.

```bash
npm install
npm test
npm run typecheck
npm run build
```
