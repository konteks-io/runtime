# @konteks/agent-core

Provider-agnostic core types, interfaces, and runtime loop for AI coding agents.

## Install

```bash
npm install @konteks/agent-core
```

Two entry points:

| Entry | Carries |
|-------|---------|
| `@konteks/agent-core` | The runtime loop, the adapter/strategy contracts, and every catalogue **type** |
| `@konteks/agent-core/models` | The model catalogue **data** and the functions that read it, including `describeAgentCapabilities` |

The split exists because the catalogues are ~25,000 lines: a service that only
runs the loop should not load them. Types cost nothing — the compiler erases
them — so they stay on the root.

## What This Is

A lightweight, 0-dependency package that defines the shared contract for building AI coding agent adapters. It provides:

- **Types & Interfaces** — `AgentAdapter`, `AgentStrategy`, `AgentEvent`, `ExecutionEvent`, and more
- **Runtime Loop** — `runAgentRuntime()` — drives the agent iteration lifecycle with built-in token budget management, timeout handling, stale session recovery, and exploration spiral detection
- **Policy Abstraction** — `PolicyEvaluator` interface for tool-use policy enforcement

## What You Get Beyond the Raw SDK

The runtime loop (`runAgentRuntime`) provides several features not available in
the base Claude Code or Pi SDKs:

| Feature | Description |
|---------|-------------|
| **Exploration Spiral Detection** | Detects when the agent is stuck exploring without making changes. Warns at 3 consecutive turns without file changes, force-stops at 8 — preventing wasted token burn. |
| **Progressive Token Budget Enforcement** | Three-tier warnings at 60% / 75% / 85% of the budget with automatic hard-stop at 100%. Keeps runs predictable and prevents runaway costs. |
| **Stale Session Recovery** | Automatically detects expired SDK sessions (e.g., process restart between iterations) and retries with a fresh session without losing iteration state. |
| **Fatal Error Classification** | Distinguishes unrecoverable errors (auth failures, model not found, missing API key) from transient failures, preventing wasted retry loops. |
| **Abort Signal Propagation** | Accepts an orchestrator `AbortSignal` via `options.signal`, merges it with the internal `AbortController`, fail-fasts if already aborted, and always aborts on clean exit so adapter signal listeners are cleaned up. |
| **Per-Iteration Token Soft Cap** | Opt-in diagnostic that warns when a single iteration exceeds `perIterationTokenPct`% of the total budget. Disabled by default — set `perIterationTokenPct` to a value in `[1, 95]` to enable. Only the cumulative cap hard-stops; the per-iteration check is a diagnostic for runaway iterations. |
| **Usage Breakdown Accounting** | Sums the prompt-cache and reasoning dimensions an adapter reports — `cumulativeCacheReadTokens`, `cumulativeCacheWriteTokens`, `cumulativeReasoningOutputTokens` on the run result, and the same three per iteration on the `AgentLoopIteration` handed to `onIterationEnd`. See [Usage dimensions](#usage-dimensions). |
| **Adapter-Hang Defense** | Wraps `adapter.run()` in `Promise.race()` against `max(timeoutMs × 1.5, 5s)`. If the adapter never returns (stall detection itself failed), the runtime breaks the loop with a fatal error, waits a bounded grace for the abandoned call to settle, and only then disposes — so teardown never runs underneath a live provider call. |
| **Lifecycle Ownership** | A run cancelled before it starts returns before `setup()` and `createAdapter()`, so nothing is acquired for a run that will never execute. Whatever is acquired is released on one exit path: `adapter.dispose()`, then the optional `AgentStrategy.teardown(result)`. |
| **Run & Iteration Correlation** | Supplies `runId` (caller-provided or `taskId`), `iterationNumber`, and `iterationId` on every adapter dispatch, and stamps them onto execution events — backfilling any an adapter omitted. `ExecutionEvent.turnIndex` stays the adapter's provider-native turn counter. |
| **Heartbeat Staleness Diagnostic** | After `adapter.run()` returns, logs a warning if the last heartbeat is older than `min(timeoutMs, 120s)`, surfacing internal adapter stalls that were recovered from. |

## Usage

### Using the Runtime Loop

```typescript
import { runAgentRuntime, buildContinuationPrompt } from "@konteks/agent-core";
import type { AgentStrategy, AgentRuntimeOptions } from "@konteks/agent-core";

const strategy: AgentStrategy = {
  setup: async () => ({ repoPath: "/path/to/repo", workspacePath: "/path/to/workspace" }),
  buildPrompt: () => "Fix the bug in src/index.ts",
  createAdapter: () => myAdapter, // implements AgentAdapter
  evaluateResult: async (ctx) => {
    if (ctx.agentResult.success) return { action: "stop", stopReason: "completed" };
    if (ctx.iterationNumber >= ctx.maxIterations) return { action: "stop", stopReason: "max_iterations_reached" };
    // Continuation prompts are built with the standalone buildContinuationPrompt() helper.
    return { action: "retry", nextPrompt: buildContinuationPrompt("previous attempt failed") };
  },
  // Optional. Called once on every exit path where setup() succeeded, after the
  // adapter is disposed; a throw is logged, never propagated.
  teardown: async () => removeWorkspace("/path/to/workspace"),
};

const options: AgentRuntimeOptions = {
  taskId: "task-123",
  // Optional; falls back to taskId. Stamped onto every dispatch and event.
  runId: "run-456",
  maxIterations: 5,
  timeoutMs: 600_000,
  maxInputTokens: 200_000,
};

const result = await runAgentRuntime(strategy, options);

console.log(result.runId);
console.log(result.stopReason);
console.log(result.filesChanged);
console.log(result.cumulativeInputTokens);
```

### Using the AgentAdapter Interface

```typescript
import type { AgentAdapter, AgentRunInput, AgentRunResult } from "@konteks/agent-core";

class MyAdapter implements AgentAdapter {
  async run(input: AgentRunInput): Promise<AgentRunResult> {
    // Implement your AI agent logic here
    return {
      success: true,
      summary: "Fixed the bug",
      events: [],
      filesChanged: ["src/index.ts"],
      commandsRun: ["npm test"],
      errors: [],
      durationMs: 5000,
    };
  }
}
```

### Usage dimensions

Beyond `inputTokens` / `outputTokens`, an adapter may report three **breakdown** dimensions. They are reported per iteration on `AgentRunResult`, delivered per iteration on the `AgentLoopIteration` passed to `onIterationEnd`, and summed on the run result.

| Dimension | Per iteration | Cumulative | Relationship |
|---|---|---|---|
| Prompt-cache reads | `cacheReadTokens` | `cumulativeCacheReadTokens` | Beside the input count — **not** part of `inputTokens` |
| Prompt-cache writes | `cacheWriteTokens` | `cumulativeCacheWriteTokens` | Beside the input count |
| Reasoning output | `reasoningOutputTokens` | `cumulativeReasoningOutputTokens` | **Inside** `outputTokens` — a breakdown, never an addend |

Two rules matter when persisting these:

- **`undefined` ≠ `0`.** Absent means the adapter never reported the dimension; `0` means it reported none. They price differently, so the runtime never coerces one into the other — a cumulative field stays `undefined` unless some iteration reported it, and a reported `0` sums to `0`.
- **Never add a breakdown into a total.** Adding `reasoningOutputTokens` to `cumulativeOutputTokens` double-counts every reasoning-model turn.

Per-adapter coverage:

| Adapter | Cache read | Cache write | Reasoning |
|---|---|---|---|
| Claude Code | ✅ | ✅ | — |
| Cline | ✅ | ✅ | — |
| Pi | ✅ | ✅ | — |
| Codex | ✅ | ✅ | ✅ |

Reasoning tokens are reported only where the provider SDK exposes a stable field. They are never inferred from output counts or provider prose — an inferred number is indistinguishable from a measured one once it reaches a billing record.

Because `onIterationEnd` fires once per adapter call, its record is the right granularity for a consumer writing one row per model invocation; the cumulative fields describe the whole run.

## API Reference

### Types

| Export | Description |
|--------|-------------|
| `AgentAdapter` | Interface with a `run(input)` method and an optional `dispose()` for resources acquired at construction |
| `StopReason` | The stop reasons the runtime produces, open-ended so a strategy can add its own |
| `BudgetEscalation` / `ExplorationEscalation` | Budget and exploration-stall pressure reported to `evaluateResult` |
| `AgentRunInput` | Input to an adapter run (taskId, runId, iterationNumber, iterationId, instructions, repoPath, workspacePath, timeoutMs, signal, sessionId, and event/truncation callbacks) |
| `AgentRunResult` | Result from an adapter run (success, summary, tokens including cache and sub-agent, filesChanged, commandsRun, errors, fatalErrors, staleSession, durationMs, events, executionEvents, sessionId, lastMessageUuid, lastHeartbeatAt, structuredOutput, modelUsage) |
| `AgentProvider` | `"claude" \| "pi" \| "cline" \| "codex"` |
| `AdapterCapabilities` | What one adapter instance advertises (structuredOutput, subAgents, mcp, sessionResume, streaming). Absent means assume none supported |
| `AgentCallbacks` | Optional `onExecutionEvent` and `onTruncation` hooks shared by run input and runtime options |
| `AgentEvent` | Discriminated union: `message`, `tool_call`, `tool_result`, `error` |
| `ExecutionEvent` | Rich trace event with run, iteration, span, parent, and tool correlation |
| `ExecutionEventType` | String union of agent lifecycle event types |
| `AgentErrorCode` | Error code string union |
| `ToolIntent` | `"read" \| "write" \| "edit" \| "bash" \| "grep" \| "file_search" \| "agent"` |
| `Phase` | `"planning" \| "executing" \| "checking" \| "review"` |
| `Logger` | Logger interface (debug, info, warn, error, child) |
| `PolicyEvaluator` | Interface for tool-use policy enforcement |
| `ToolPolicyEvaluation` | Policy evaluation result (allowed, denyMessage, updatedInput) |
| `ToolPolicyContext` | Context passed to policy evaluator |
| `AgentStrategy` | Strategy interface (setup, buildPrompt, createAdapter, evaluateResult, and optional teardown) |
| `StrategySetup` | Result of strategy setup (repoPath, workspacePath) |
| `SubAgentDefinition` | Provider-agnostic sub-agent definition (description, prompt, tools, model, skills, permissionMode) |
| `IterationDecision` | Decision from evaluateResult (action, stopReason, nextPrompt, errors, filesChanged, iterationRecord, executionEvents) |
| `EvaluateIterationContext` | Context passed to evaluateResult (iterationNumber, iterationId, prompt, agentResult, allErrors, maxIterations, elapsedMs, iterationDurationMs, consecutiveTurnsWithoutChanges, budgetUsedPct, budgetEscalation, explorationEscalation, signal). `elapsedMs` is measured **after** the iteration ran |
| `AgentRuntimeOptions` | Options for `runAgentRuntime` (taskId, runId, maxIterations, timeoutMs, iterationTimeoutMs, maxInputTokens, perIterationTokenPct, promptAugmentation, signal, handleStaleSession, maxStaleSessionRetries, initialSessionId, isCancelled, and iteration/event/truncation callbacks) |
| `AgentRuntimeResult` | Result from `runAgentRuntime` (stopReason, runId, iterationCount, filesChanged, errors, cumulativeInputTokens, cumulativeOutputTokens, cumulativeCacheReadTokens, cumulativeCacheWriteTokens, cumulativeReasoningOutputTokens, subAgentInputTokens, subAgentOutputTokens, usageBySubAgent, executionEvents, sessionId, lastMessageUuid) |
| `AgentLoopIteration` | Record of a single iteration (iterationNumber, prompt, filesChanged, commandsRun, agentSummary, errors, tokens, durationMs, inputTokens, outputTokens, cacheReadTokens, cacheWriteTokens, reasoningOutputTokens, modelUsage, agentEvents, sessionId, lastMessageUuid, lastHeartbeatAt, metadata) |

### Functions

| Export | Description |
|--------|-------------|
| `runAgentRuntime(strategy, options, logger?)` | Main runtime loop. Drives iteration lifecycle with token budget, timeout, and spiral detection. |
| `validateRuntimeOptions(opts)` | Validate `AgentRuntimeOptions` constraints. Throws `AgentError` on violation. |
| `buildContinuationPrompt(reason)` | Build a continuation prompt string from a reason. Call inside `evaluateResult` to set `IterationDecision.nextPrompt` (replaces the removed `buildContinuation()` strategy method). |

### Values

| Export | Description |
|--------|-------------|
| `AgentError` | Error class with typed error codes (`AGENT_TIMEOUT`, `INVALID_OPTION`, etc.) and optional `cause` |
| `nullLogger` | No-op `Logger` implementation |

### Model & Provider Query

> Imported from **`@konteks/agent-core/models`**, not the package root. The
> catalogues are ~25,000 lines of data; the root carries the runtime contracts
> and every catalogue *type* (erased by the compiler, so free), and this entry
> carries the data and the functions that read it. A packaging test walks the
> root's runtime module graph and fails if a catalogue module reappears in it.

A catalog has one of two shapes. Claude and Codex are **flat** — a list of
models. Pi and Cline are **nested** — a list of providers, each holding its own
models. A `ProviderModel` is always a model in both cases; a provider is a
`ModelProviderGroup`, which says so in the type rather than in a comment.

| Export | Description |
|--------|-------------|
| `ProviderModel` | A concrete model (id, displayName, provider, providerId, contextWindow, maxOutputTokens, supportsReasoning, supportsImages, status). Its `models?` field is **deprecated** — an entry carrying it is a provider group, not a model |
| `ModelProviderGroup` | A model provider inside a nested catalog (id, displayName, provider, models) — never nested further |
| `ModelSelector` | `"small" \| "medium" \| "large" \| (string & {})` — tier alias or concrete model ID |
| `ModelDiscovery` | `"catalog" \| "catalog_plus_account" \| "curated_subset"` |
| `ClaudeModelId` / `CodexModelId` | Recognized model identifier strings |
| — | *(the four types above are also exported from the package root)* |
| `TIER_ALIASES` | Map of tier aliases to concrete model IDs per provider |
| `listModels(agent)` | Overloaded: `ProviderModel[]` for `"claude"`/`"codex"`, `ModelProviderGroup[]` for `"pi"`/`"cline"`. A literal agent picks the right return type at the call site |
| `listProviderGroups(agent)` | The nested case stated explicitly — `ModelProviderGroup[]`, empty for the flat agents. Reach for this when the agent is a variable |
| `getModel(agent, id)` | Return a single `ProviderModel` by ID. Models only — a Pi/Cline provider id does not resolve here |
| `getProviderGroup(agent, providerId)` | Return one provider from a nested catalog. Ask here when you want a provider |
| `getProviders(agent)` | Return `string[]` of underlying provider IDs — `[]` for the single-provider agents |
| `isModelSupported(agent, model)` | Check whether a model string is compatible with an agent adapter |
| `catalogMembership(agent, model)` | `in_catalog` / `not_in_catalog_permitted` / `rejected` — the distinction `isModelSupported` cannot express |
| `resolveCatalogEntry(agent, providerId, modelId)` | Resolve a nested-catalog entry by its real identity, the provider/model pair |
| `AGENT_MODEL_DISCOVERY` | Per agent: `catalog`, `catalog_plus_account`, or `curated_subset` |

Row identity in a nested catalog is the `(providerId, modelId)` **pair**.
Resolving by model id alone silently picks whichever provider sorts first, which
is why `resolveCatalogEntry` and `CuratedSetupModel` both force the pair.

### Agent Setup Capabilities

What each agent can run and how it authenticates, so no service restates it.

`describeAgentCapabilities`, `CURATED_SETUP_MODELS`, `MAX_CURATED_MODELS_PER_AGENT`,
`AGENT_DISPLAY_NAMES`, and `providerDisplayName` come from
**`@konteks/agent-core/models`** — the row builder resolves every advertised
entry against the catalogue, so it pays for the catalogue. The row *types* and
`AGENT_AUTH_CAPABILITIES` stay on the package root.

| Export | Description |
|--------|-------------|
| `describeAgentCapabilities(input)` | Build the capability rows for one product role. Callers may supply a legacy enabled-agent list, managed-local-auth gating, connection availability, and a capability classifier; every catalog agent remains present, with disabled agents marked unavailable, while models, auth modes, labels, billing, and probe requirements come from here |
| `DescribeAgentCapabilitiesInput` | Its input — `role`, plus the optional deployment-availability `agents`, `managedLocalAuthConfigured`, `connectionAvailability`, `capabilityClassification`, and `policyMetadata` seams |
| `AgentCapabilityRow` | One advertised `(role, runtimeId, providerId, modelId)` row with its auth mode, credential kinds, discovery policy, required capabilities, availability, billing, and policy metadata |
| `ProductRole` | `"planner" \| "executor" \| "assistant" \| "search"` |
| `RuntimeAvailability` / `RuntimeReason` | Whether a row is selectable, and the machine-readable `{ code, message }` saying why not |
| `AvailabilityDecision` | What a `connectionAvailability` callback returns to override a row's availability |
| `AGENT_AUTH_CAPABILITIES` | Auth matrix as data — modes, credential kinds, the adapter channel each resolves to, and recorded exclusions. A drift test in `@konteks/agent-adapters` proves it matches the code |
| `AgentAuthCapability` / `AgentAuthMode` / `AgentCredentialKind` | The types that matrix is built from |
| `CURATED_SETUP_MODELS` | The `(providerId, modelId)` pairs setup advertises. Not a permitted-model list: the full catalogs stay the validation surface and the save-time probe is the gate |
| `CuratedSetupModel` | One curated entry — the pair, forced, so a model id alone can never identify a row |
| `MAX_CURATED_MODELS_PER_AGENT` | The bound the curated slice is held to |
| `AGENT_DISPLAY_NAMES` / `providerDisplayName(id)` | Human labels, so no UI keeps its own id→label map |

The recommended default per role lives in `@konteks/backstage-plugin-common`
(`DEFAULT_ROLE_PRESET`, `applyPreset`) — it is the one thing allowed to differ
between agents.

**Advertising a model is not the same as being allowed to route it.** This
package says what exists; the reviewed capability registry in
`@konteks/backstage-plugin-common` says what may be routed, and it denies an
unclassified model for *every* role, not just strong-required ones. Pass
`capabilityClassification` so a model nothing has reviewed is advertised
`policy_blocked` with a safe reason instead of being offered as a candidate that
delivery will always refuse:

```ts
import { classifyModelCapabilityTier, MODEL_CAPABILITY_POLICY_VERSION }
  from "@konteks/backstage-plugin-common";

const rows = describeAgentCapabilities({
  role: "planner",
  capabilityClassification: (row) => {
    const tier = classifyModelCapabilityTier(row.modelId);
    return tier ? { tier, policyVersion: MODEL_CAPABILITY_POLICY_VERSION } : undefined;
  },
});
```

The classifier is injected rather than imported because this package stays
dependency-free and ESM while the registry is CommonJS and zod-backed. Omitting
it keeps the previous behaviour. A test in this package
(`advertised-model-capability.test.ts`) asserts the two tables cannot diverge.

## Related Packages

| Package | Description |
|---------|-------------|
| [`@konteks/agent-adapters`](../agent-adapters) | Provider adapters (Claude Code, Pi, Cline, Codex) and shared utilities |
| [`@konteks/plugin-platform`](../plugin-platform) | Backstage Platform backend plugin — combined Billing + RBAC |
| [`@konteks/plugin-secret`](../plugin-secret) | Backstage Secret backend plugin |
| [`@konteks/backstage-plugin-common`](../backstage-plugin-common) | Shared types for Backstage plugins |

## License

Apache-2.0
