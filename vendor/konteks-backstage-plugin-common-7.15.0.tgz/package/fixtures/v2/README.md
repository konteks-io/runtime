# Shared v2 wire fixtures

Canonical examples of the estimate, token, and settlement integrity contracts.
They ship inside the published package so consumers in other languages — the Go
E2E controller, Python ingestion — validate **the same bytes** this package
parses, instead of a re-typed copy that drifts.

## Shape

Every file is an envelope:

```json
{
  "description": "why this example exists and what it demonstrates",
  "payload": { }
}
```

Validate `payload` directly against the corresponding schema. It needs no
pre-processing: every v2 schema is strict, and `payload` contains exactly the
fields the schema declares. The `description` sits outside it so the fixture can
explain itself without a reader having to know to strip a field first.

| File | Schema |
|---|---|
| `settlement-snapshot-v2.json` | `SettlementSnapshotV2Schema` |
| `meter-occurrence-v2.json` | `MeterOccurrenceV2Schema` |
| `provider-call-observation-v2.json` | `ProviderCallObservationV2Schema` |
| `provider-money-position-v1.json` | `ProviderMoneyPositionV1Schema` |
| `estimate-feature-snapshot-v1.json` | `EstimateFeatureSnapshotV1Schema` |
| `estimate-outcome-v1.json` | `EstimateOutcomeV1Schema` |
| `forecast-profile-v1.json` | `ForecastProfileV1Schema` |
| `estimate-derivation-v1.json` | `EstimateDerivationV1Schema` |
| `economic-guidance-projection-v1.json` | `EconomicGuidanceProjectionV1Schema` |
| `session-runtime-transition-v1.json` | `RemoteRecoveryNoticeSchema` |
| `harness-execution-session-handoff-v1.json` | `HarnessExecutionSessionHandoffRequestSchema` |
| `remote-execution-continuation-policy-v1.json` | `RemoteExecutionContinuationPolicySchema` |

## What these examples deliberately show

They encode the honest shapes rather than the convenient ones, because those are
the cases a consumer is most likely to get wrong:

- an expired reservation settling as `unsettled` with zero capture and no ledger
  entry, rather than a receipt claiming Story Points;
- a minute quantity that reproduces its own single ceiling from retained
  milliseconds and spans more than one lease;
- a Codex call whose cached input is a **subset** of total input, and whose
  provider money is unavailable with a reason instead of zero;
- an estimate-time feature snapshot with explicit unknown topology provenance;
- a reconciled terminal outcome that is eligible only after feature capture;
- a shadow forecast profile with a structured, non-executable cohort selector;
- a deterministic derivation that falls back independently per dimension; and
- armed, advisory-only model guidance whose checkpoint arm stays independent.
- a negotiated continuation policy that can keep only one exact ACP operation
  active, never permits local tools, and states every authority deadline that
  still fences it.

No fixture contains an email address, prompt, tool result, provider body, or
credential, and a test asserts it.
