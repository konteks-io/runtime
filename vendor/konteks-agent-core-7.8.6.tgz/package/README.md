# @konteks/agent-core

Provider-agnostic core types and interfaces for AI coding agents.

## Install

```bash
npm install @konteks/agent-core
```

Two entry points:

| Entry | Carries |
|-------|---------|
| `@konteks/agent-core` | The adapter/strategy contracts and every catalogue **type** |
| `@konteks/agent-core/models` | The model catalogue **data** and the functions that read it |

The split exists because the catalogues are ~25,000 lines: a service that only
needs the contracts should not load them. Types cost nothing — the compiler
erases them — so they stay on the root.

## What This Is

A lightweight, 0-dependency package that defines the shared contract for building AI coding agent adapters. It provides:

- **Types & Interfaces** — `AgentAdapter`, `AgentStrategy`, `AgentEvent`, `ExecutionEvent`, and more
- **Policy Abstraction** — `PolicyEvaluator` interface for tool-use policy enforcement

## Usage

### Using the AgentAdapter Interface

```typescript
import type { AgentAdapter, AgentRunInput, AgentRunResult } from "@konteks/agent-core";

class MyAdapter implements AgentAdapter {
  async run(input: AgentRunInput): Promise<AgentRunResult> {
    // Implement your AI agent logic here
    return {
      success: true,
      summary: "Fixed the bug",
      events: [],
      filesChanged: ["src/index.ts"],
      commandsRun: ["npm test"],
      errors: [],
      durationMs: 5000,
    };
  }
}
```

### Usage dimensions

Beyond `inputTokens` / `outputTokens`, an adapter may report three **breakdown** dimensions on `AgentRunResult`. `AgentLoopIteration` carries the same three per iteration, and `AgentRuntimeResult` their sums.

| Dimension | Per iteration | Cumulative | Relationship |
|---|---|---|---|
| Prompt-cache reads | `cacheReadTokens` | `cumulativeCacheReadTokens` | Beside the input count — **not** part of `inputTokens` |
| Prompt-cache writes | `cacheWriteTokens` | `cumulativeCacheWriteTokens` | Beside the input count |
| Reasoning output | `reasoningOutputTokens` | `cumulativeReasoningOutputTokens` | **Inside** `outputTokens` — a breakdown, never an addend |

Two rules matter when persisting these:

- **`undefined` ≠ `0`.** Absent means the adapter never reported the dimension; `0` means it reported none. They price differently, so never coerce one into the other: a cumulative field stays `undefined` unless some iteration reported it, and a reported `0` sums to `0`.
- **Never add a breakdown into a total.** Adding `reasoningOutputTokens` to `cumulativeOutputTokens` double-counts every reasoning-model turn.

The ACP adapter in `@konteks/agent-adapters` reports a dimension only when the bridge's ACP usage carries it. Reasoning tokens are reported only where the provider exposes a stable field. They are never inferred from output counts or provider prose — an inferred number is indistinguishable from a measured one once it reaches a billing record.

## API Reference

### Types

| Export | Description |
|--------|-------------|
| `AgentAdapter` | Interface with a `run(input)` method and an optional `dispose()` for resources acquired at construction |
| `StopReason` | The stop reasons the runtime produces, open-ended so a strategy can add its own |
| `BudgetEscalation` / `ExplorationEscalation` | Budget and exploration-stall pressure reported to `evaluateResult` |
| `AgentRunInput` | Input to an adapter run (taskId, runId, iterationNumber, iterationId, instructions, repoPath, workspacePath, timeoutMs, signal, sessionId, and event/truncation callbacks) |
| `AgentRunResult` | Result from an adapter run (success, summary, tokens including cache and sub-agent, filesChanged, commandsRun, errors, fatalErrors, staleSession, durationMs, events, executionEvents, sessionId, lastMessageUuid, lastHeartbeatAt, structuredOutput, modelUsage) |
| `AgentProvider` | `"claude" \| "pi" \| "cline" \| "codex"` |
| `AdapterCapabilities` | What one adapter instance advertises (structuredOutput, subAgents, mcp, sessionResume, streaming). Absent means assume none supported |
| `AgentCallbacks` | Optional `onExecutionEvent` and `onTruncation` hooks shared by run input and runtime options |
| `AgentEvent` | Discriminated union: `message`, `tool_call`, `tool_result`, `error` |
| `ExecutionEvent` | Rich trace event with run, iteration, span, parent, and tool correlation |
| `ExecutionEventType` | String union of agent lifecycle event types |
| `AgentErrorCode` | Error code string union |
| `ToolIntent` | `"read" \| "write" \| "edit" \| "bash" \| "grep" \| "file_search" \| "agent"` |
| `Phase` | `"planning" \| "executing" \| "checking" \| "review"` |
| `Logger` | Logger interface (debug, info, warn, error, child) |
| `PolicyEvaluator` | Interface for tool-use policy enforcement |
| `ToolPolicyEvaluation` | Policy evaluation result (allowed, denyMessage, updatedInput) |
| `ToolPolicyContext` | Context passed to policy evaluator |
| `AgentStrategy` | Strategy interface (setup, buildPrompt, createAdapter, evaluateResult, and optional teardown) |
| `StrategySetup` | Result of strategy setup (repoPath, workspacePath) |
| `SubAgentDefinition` | Provider-agnostic sub-agent definition (description, prompt, tools, model, skills, permissionMode) |
| `IterationDecision` | Decision from evaluateResult (action, stopReason, nextPrompt, errors, filesChanged, iterationRecord, executionEvents) |
| `EvaluateIterationContext` | Context passed to evaluateResult (iterationNumber, iterationId, prompt, agentResult, allErrors, maxIterations, elapsedMs, iterationDurationMs, consecutiveTurnsWithoutChanges, budgetUsedPct, budgetEscalation, explorationEscalation, signal). `elapsedMs` is measured **after** the iteration ran |
| `AgentRuntimeOptions` | Options for a runtime run (taskId, runId, maxIterations, timeoutMs, iterationTimeoutMs, maxInputTokens, perIterationTokenPct, promptAugmentation, signal, handleStaleSession, maxStaleSessionRetries, initialSessionId, isCancelled, and iteration/event/truncation callbacks) |
| `AgentRuntimeResult` | Result of a runtime run (stopReason, runId, iterationCount, filesChanged, errors, cumulativeInputTokens, cumulativeOutputTokens, cumulativeCacheReadTokens, cumulativeCacheWriteTokens, cumulativeReasoningOutputTokens, subAgentInputTokens, subAgentOutputTokens, usageBySubAgent, executionEvents, sessionId, lastMessageUuid) |
| `AgentLoopIteration` | Record of a single iteration (iterationNumber, prompt, filesChanged, commandsRun, agentSummary, errors, tokens, durationMs, inputTokens, outputTokens, cacheReadTokens, cacheWriteTokens, reasoningOutputTokens, modelUsage, agentEvents, sessionId, lastMessageUuid, lastHeartbeatAt, metadata) |

### Values

| Export | Description |
|--------|-------------|
| `AgentError` | Error class with typed error codes (`AGENT_TIMEOUT`, `INVALID_OPTION`, etc.) and optional `cause` |
| `nullLogger` | No-op `Logger` implementation |

### Model & Provider Query

> Imported from **`@konteks/agent-core/models`**, not the package root. The
> catalogues are ~25,000 lines of data; the root carries the runtime contracts
> and every catalogue *type* (erased by the compiler, so free), and this entry
> carries the data and the functions that read it. A packaging test walks the
> root's runtime module graph and fails if a catalogue module reappears in it.

Every catalog is **flat**, a list of models, so a `ProviderModel` is always a
model.

| Export | Description |
|--------|-------------|
| `ProviderModel` | A concrete model (id, displayName, provider, providerId, contextWindow, maxOutputTokens, supportsReasoning, supportsImages, status). Its `models?` field is **deprecated**: no supported catalog nests models |
| `ModelSelector` | `"small" \| "medium" \| "large" \| (string & {})` — tier alias or concrete model ID |
| `ModelDiscovery` | `"catalog" \| "catalog_plus_account" \| "curated_subset"` |
| — | *(the three types above are also exported from the package root)* |
| `listModels(agent)` | The agent's `ProviderModel[]` |
| `getModel(agent, id)` | Return a single `ProviderModel` by ID |

### Agent Setup Capabilities

What each agent can run and how it authenticates, so no service restates it.

`providerDisplayName` comes from **`@konteks/agent-core/models`**. The row
*types* stay on the package root.

| Export | Description |
|--------|-------------|
| `AgentCapabilityRow` | One advertised `(role, runtimeId, providerId, modelId)` row with its auth mode, (always empty) credential kinds, discovery policy, required capabilities, availability, billing, and policy metadata |
| `ProductRole` | `"planner" \| "executor" \| "assistant" \| "search"` |
| `RuntimeAvailability` | Whether a row is selectable |
| `AgentAuthMode` | How an agent authenticates (`managed_local_auth`: it signs in on the person's own computer over ACP) |
| `providerDisplayName(id)` | Human label for a model provider id, so no UI keeps its own id→label map |

**Advertising a model is not the same as being allowed to route it.** This
package says what exists; the reviewed capability registry in
`@konteks/backstage-plugin-common` says what may be routed, and it denies an
unclassified model for *every* role, not just strong-required ones.

## Related Packages

| Package | Description |
|---------|-------------|
| [`@konteks/agent-adapters`](../agent-adapters) | The ACP adapter and shared utilities |
| [`@konteks/plugin-platform`](../plugin-platform) | Backstage Platform backend plugin — combined Billing + RBAC |
| [`@konteks/plugin-secret`](../plugin-secret) | Backstage Secret backend plugin |
| [`@konteks/backstage-plugin-common`](../backstage-plugin-common) | Shared types for Backstage plugins |

## License

Apache-2.0
