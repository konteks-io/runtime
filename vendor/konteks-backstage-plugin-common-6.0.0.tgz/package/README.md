# @konteks/backstage-plugin-common

Shared types, constants, and contracts for Konteks platform components — Backstage plugins, agent harness, and core.

Runtime dependency: `zod` for schema validation at trust boundaries. Dev dependencies: `typescript`, `vitest`.

## Modules

### `remote-instance-internal` — Native Recovery Snapshots

Server-only recovery contracts expose strict unsigned
`RemoteReconnectIntentSnapshotSchema` and
`RemoteReconciliationReceiptSnapshotSchema` for persistence before a network
attempt. Their snapshot digest helpers use the same semantic bytes as the signed
request helpers, without retaining proof, connection or lease material. Receipt
ordering, unique identities and terminal-evidence correlation remain identical
in both forms. Signed request helpers still require actual transport proof.
These schemas do not establish durable storage, Core acceptance or permission to
resume work; those remain responsibilities of their runtime owners.

### `events` — Event Topics & Payloads

Billing/credit event topic constants and typed payloads for inter-plugin communication via Backstage's event system.

### `leases` — Runtime License Leases

Signed runtime lease types (`RuntimeLicenseLease`, `RuntimeInstallType`, `RuntimeLeaseStatus`) and `validateRuntimeLease()` for issuer/verifier alignment without external schema dependencies.

### `permissions` — Permission Registration Contracts

`PermissionTier` enum, `PluginPermission`, and `PermissionRegistrationService` interface for plugin-to-platform permission registration.

### `routing` — Workload Routing Contracts

**Exports:**

| Export | Kind | Description |
|--------|------|-------------|
| `RepositoryProvider` | Type | `'github' \| 'gitea' \| 'gitlab'` |
| `RuntimeKind` | Type | `'managed' \| 'onprem'` |
| `ExecutionPreference` | Type | `'managed_only' \| 'onprem_preferred' \| 'onprem_required' \| 'hybrid_allowed'` |
| `VcsLocationHint` | Type | `'managed' \| 'onprem_only' \| 'any'` |
| `TaskRuntimeClassification` | Type | `'local_required' \| 'managed_allowed' \| 'same_runtime_required'` |
| `WorkloadRoutingRequest` | Interface | Request core's routing service evaluates |
| `WorkloadRoutingDecision` | Interface | Core's routing decision — persisted on the plan |
| `RepositoryProviderSchema` | ZodSchema | Runtime validation for `RepositoryProvider` |
| `RuntimeKindSchema` | ZodSchema | Runtime validation for `RuntimeKind` |
| `ExecutionPreferenceSchema` | ZodSchema | Runtime validation for `ExecutionPreference` |
| `VcsLocationHintSchema` | ZodSchema | Runtime validation for `VcsLocationHint` |
| `TaskRuntimeClassificationSchema` | ZodSchema | Runtime validation for `TaskRuntimeClassification` |
| `WorkloadRoutingRequestSchema` | ZodSchema | Runtime validation for `WorkloadRoutingRequest` |
| `WorkloadRoutingDecisionSchema` | ZodSchema | Runtime validation for `WorkloadRoutingDecision` |
| `NO_ELIGIBLE_RUNTIME` etc. | Const | Structured routing error codes |

Shared by core (routing authority), harness (plan_create MCP intake), and ai-agent-assistant (plan dispatch). Zod schemas enable runtime validation at trust boundaries across all consumers.

#### Pull-Based Dispatch Contracts

Pull-based dispatch moves plan intake from a push model to a pull model: the runtime polls for work assignments, claims them, executes, and reports results. All schemas are Zod-validated at trust boundaries.

| Export | Kind | Description |
|--------|------|-------------|
| `WorkType` | Type | `'plan' \| 'task'` |
| `AssignmentStatus` | Type | `'pending' \| 'claimed' \| 'running' \| 'completed' \| 'failed'` |
| `PlanStatus` | Type | `'pending' \| 'claimed' \| 'running' \| 'completed' \| 'failed'` |
| `TaskSummary` | Interface | Lightweight task descriptor for pull-based dispatch |
| `PrincipalClaims` | Interface | Identity claims from the calling principal |
| `PlanRepository` | Interface | Repo descriptor within a submitted plan |
| `PlanSubmissionPayload` | Interface | Plan submitted to the pull queue |
| `WorkAssignment` | Interface | Work assigned to a runtime on pull |
| `PullRequest` | Interface | Runtime polls with this request shape |
| `PullResponse` | Interface | Core responds with 0 or more assignments |
| `ClaimResult` | Interface | Runtime acknowledges claiming an assignment |
| `WorkReport` | Interface | Runtime reports execution outcome |
| `ReportAck` | Interface | Core acknowledges receipt of the report |
| `WorkTypeSchema` … `ReportAckSchema` | ZodSchema | One schema per interface for runtime validation |

### `session-harness-context` — Session-Threaded Harness Intake Context

**Exports:**

| Export | Kind | Description |
|--------|------|-------------|
| `SessionHarnessContext` | Interface | Harness-relevant context threaded into a session (all fields optional) |
| `SessionHarnessContextSchema` | ZodSchema | Runtime validation for `SessionHarnessContext` |
| `SESSION_HARNESS_CONTEXT_KEY` | `'harness'` | Well-known key in session/run metadata |
| `isSessionHarnessContext(value)` | Type guard | Delegates to `SessionHarnessContextSchema.safeParse()` |

Shared by the app (BFF), core, ai-agent-assistant, and harness. Injected into `session.meta` / `run.meta` at session intake and carried through plan_create MCP to core's routing engine.

### `runtime-config` — Runtime Config Registry

Single source of truth for every DB-canonical runtime tunable. Shared between harness (owner), core (control-plane management surface), and app (admin UI rendering). Exports `RUNTIME_CONFIG_REGISTRY`, `RuntimeConfig` type, and lookup helpers.

### `notifications` — Notification Action Types

`NotificationAction` — shared action button contract for notification cards rendered by mobile/web clients. Defines the `key`, `role` (`confirm` | `reject` | `input`), `label`, `url`, and optional `bodySchema` for input-role actions.

### `secret-refs` — Logical Secret Ref Primitives

Parser, validator, and redaction model for logical secret references shared across core, agent-harness, agent-assistant, and app. Avoids each plugin maintaining a slightly different `mount/path#key` parser.

**Exports:**

| Export | Kind | Description |
|--------|------|-------------|
| `LogicalSecretRef` | Type | `` `${string}/${string}#${string}` `` — canonical shape: `mount/cluster/plugin/tenant/key#field` |
| `SecretBindingReference` | Interface | `{ cluster, plugin, tenant, key, field? }` — structured Vault path reference |
| `CLUSTER_RE`, `PLUGIN_RE`, `TENANT_RE`, `KEY_RE` | RegExp | Segment validation regexes (ported from `@konteks/plugin-secret`) |
| `LOGICAL_SECRET_REF_SEGMENT_COUNT` | `5` | Expected `/`-separated path segments before `#` |
| `MASKED_KEY_REPLACEMENT` | `"***"` | Replacement string for key masking |
| `validateLogicalSecretRef(value)` | Function | Throws `TypeError` on malformed/env-style refs |
| `vaultPathToLogicalRef(vaultPath, field?, mountPath?)` | Function | KV v2 path → logical ref conversion |
| `logicalRefToSecretBinding(ref)` | Function | Parse logical ref → structured binding |
| `maskSecretRef(ref)` | Function | Replace key segment with `***` for logs/UI |
| `logicalSecretRef()` | Function | Zod schema wrapping `validateLogicalSecretRef` — validates a `LogicalSecretRef` inline in a larger contract (shape-only, never resolves the secret). Failures surface as Zod issues, so `safeParse` returns `success:false` instead of throwing. |

**Usage:**

```ts
import {
  validateLogicalSecretRef,
  vaultPathToLogicalRef,
  logicalRefToSecretBinding,
  maskSecretRef,
} from '@konteks/backstage-plugin-common';

// Convert a Vault KV v2 path to a logical ref
const ref = vaultPathToLogicalRef(
  'secret/data/prod/mcp/acme/api-key',
  'token',
);
// => "secret/prod/mcp/acme/api-key#token"

// Validate at trust boundaries
const validated = validateLogicalSecretRef(ref);

// Parse to structured binding
const binding = logicalRefToSecretBinding(validated);
// => { cluster: 'prod', plugin: 'mcp', tenant: 'acme', key: 'api-key', field: 'token' }

// Mask for safe logging
maskSecretRef(ref);
// => "secret/prod/mcp/acme/***#token"
```

**Path convention:** Assumes HashiCorp Vault KV v2 paths (`{mount}/data/{cluster}/{plugin}/{tenant}/{key}`). The `/data/` segment is stripped during conversion. Default mount path is `"secret"`; override via the optional `mountPath` parameter.

**`field?` semantics:** The `field` property on `SecretBindingReference` identifies a specific key within the resolved secret object. **Field extraction is a caller responsibility** — this package parses and round-trips `field` but does not resolve secret values.

### `billing` — Canonical Monetization Contracts

Shared Story Point, quote, reservation, entitlement, BYOK provider-cost, and usage-event contracts so `core`, `ai-agent-assistant`, `ai-agent-harness`, and `app` speak one billing language. This layer owns the **unit system and wire shapes**, never pricing policy or balance state — those remain in `core`. All exports are re-exported from the package root (`@konteks/backstage-plugin-common`).

| Module | Exports | Description |
|--------|---------|-------------|
| `billing/story-points` | `StoryPointAmountSchema`, `storyPointsToMeteringUnits`, `meteringUnitsToStoryPointAmount`, `formatStoryPoints`, `METERING_UNITS_PER_STORY_POINT`, `REVERSAL_EVENT_TYPES` | Canonical Story Point amount + integer-backed conversion (1 SP = 1000 metering units; 0.001 SP = 1 unit). Rejects negative usage unless a reversal/refund/release/correction event type is supplied. Formatter: 2-decimal display, 3-decimal export. |
| `billing/money` | `MoneyAmountSchema`, `CurrencyCodeSchema` | ISO 4217 currency + integer minor units. No implicit decimal assumptions. |
| `billing/plans` | `PLAN_IDS`, `PlanIdSchema`, `PlanSchema` | Canonical plan ids `free`/`builder`/`team`/`scale`/`enterprise` + shared plan shape. |
| `billing/entitlements` | `EntitlementsSchema`, `ENTITLEMENT_KEYS`, `EntitlementEvaluationSchema`, `EntitlementReasonCodeSchema` | 19 typed plan gates (Free→Enterprise) + evaluation result with type-safe reason codes. |
| `billing/meters` | `METER_CATALOG`, `METER_IDS`, `MeterIdSchema`, `MeterDefinitionSchema`, `getMeterDefinition` | Stable meter ids across free/chat/planning/MCP/harness/runtime/validation/failure with per-meter metadata (chargeability, pricing basis, quote/auth/idempotency requirements). Ids only, not the price table. |
| `billing/quote` | `QuoteRequestSchema`, `QuoteResponseSchema`, `QuoteDimensionsSchema`, `QuoteLineItemSchema` | Quote request/response with line items, Story Point totals, budget/approval flags, cheaper modes. External provider estimate is kept **separate** from Story Point totals. |
| `billing/reservations` | `AuthorizationRequestSchema`, `AuthorizationResponseSchema`, `ReservationMetadataSchema`, `ReservationStateSchema`, `RESERVATION_LIFECYCLE_EVENTS` | Authorize/reserve/commit/release/reverse contracts. UUID reservation ids; strict metadata rejects truthy-but-invalid billing metadata. |
| `billing/provider-cost` | `ProviderConnectionDescriptorSchema`, `ExternalProviderCostEstimateSchema`, `ProviderSpendThresholdSchema`, `ProviderSpendThresholdSetSchema`, `ProviderSpendObservationSchema`, `findProviderSpendThreshold` | Provider-neutral BYOK connection descriptor (`keyRef` validated as a `LogicalSecretRef` — shape-only, never a secret value, no provider restriction) + external cost estimate + provider-spend **warning threshold** (currency + positive integer minor units), its canonical per-currency **set** (`ProviderSpendThresholdSet` — at most one threshold per currency; `findProviderSpendThreshold` selects the same-currency entry), and the observed-spend shape. All provider money — currency-tagged, compared same-currency only (no FX), never folded into Story Point totals. |
| `billing/usage-events` | `UsageEventSchema`, `USAGE_EVENT_TYPES`, `ProviderUsageSchema`, `BatchUsageEventPayloadSchema`, `BatchEventResultSchema`, `BatchUsageEventResponseSchema` | One usage-event envelope covering quote/reservation/work/failure/PR/review/merge/runtime/validation/provider/catalog events, plus the canonical batch `{ events: UsageEvent[] }` contract with per-event ingestion results. |

**Usage:**

```ts
import {
  storyPointsToMeteringUnits,
  meteringUnitsToStoryPointAmount,
  QuoteResponseSchema,
} from '@konteks/backstage-plugin-common';

// Always do math in integer metering units, never on the decimal string.
const units = storyPointsToMeteringUnits('1.25'); // => 1250
const amount = meteringUnitsToStoryPointAmount(units); // { unit: 'story_points', storyPoints: '1.25', meteringUnits: 1250, precision: 2 }

// Refunds require an explicit reversal event type.
storyPointsToMeteringUnits('-1', { eventType: 'refund' }); // => -1000

// Validate a quote at the trust boundary.
const quote = QuoteResponseSchema.parse(payload);
```

### `lifecycle` — Governed Delivery Contracts

Prompt identity, capability tiers, execution profiles, quote assumptions, budget envelopes, delivery authority, and lifecycle invocations. Two invariants in this layer are worth stating at the README level because getting either wrong fails silently and late.

**A delivery is classified under the policy it pinned, never the current one.** `ResolvedExecutionRouteManifest` records the `capabilityPolicyVersion` its routes were resolved under, and `ExecutionProfileRef` carries that version onward — it is the one object that reaches quote assumptions, the approved authority, the budget envelope, and every invocation. Build a ref with `executionProfileRefFromManifest()` so the version is copied rather than assembled, and read it with `resolvePinnedCapabilityPolicyVersion()`, which **throws** on a legacy ref instead of falling back to `MODEL_CAPABILITY_POLICY_VERSION`. `AuthorizedDeliveryBudgetEnvelopeSchema` rejects an envelope whose per-route `capabilityPolicyVersion` disagrees with its own pinned ref — that disagreement is precisely the symptom of a producer reading the global default.

**The executor names a unit; the envelope prices it.** An envelope carries `schemaVersion: 'authorized-budget-envelope-v2'` and `unitReservations` — the authoritative schedule of every bounded unit the approved lifecycle may admit, each priced from the quote's pinned price snapshot. The executing service sends the unit's identity (`routeId?`, `lifecycleRole`, `unitKind`, `meterId`) and `resolveUnitReservation()` answers with the amount; `BudgetAdmissionRequest` carries **no** `reserveMeteringUnits` for a caller to propose. A unit absent from the schedule is denied `unit_not_scheduled` — there is no default reserve to fall back on, and a `0` reserve is a real quoted price (a free meter, or a sub-unit whose parent carries the charge), never a stand-in for "unpriced".

A unit's identity is the tuple `(routeId, lifecycleRole, unitKind, meterId)` — `reserveMeteringUnits` is the price that tuple resolves to, never part of it — and an absent `routeId` is its own identity value rather than a wildcard, so a caller cannot keep a quoted meter while changing the route or role it runs under. `AuthorizedDeliveryBudgetEnvelopeSchema` rejects a duplicated identity (two prices for one unit would make the charge depend on array order) and a scheduled unit naming a route the envelope does not quote.

**Reconciliation reports observations, not conclusions.** `BudgetReconciliationRequest` carries `observedMeters` — meter ids and quantities. It deliberately has no `actualMeteringUnits`: pricing a quantity needs the pinned price snapshot the caller does not hold, so an actual sent from outside would be the same unverifiable number the schedule exists to eliminate, arriving where nothing is left to check it. Core prices the observation and `computeReconciliation()` returns the authoritative actual with the resulting balances. Exceeding the *reservation* is ordinary variance and settles as `reconciled`; exceeding the *authorized maximum* returns the distinct `overrun` status with what was clamped, because that is an approval-boundary event and folding it into a clean settlement would hide it. Where that conversion has not run, `storyPoints.consumedMeteringUnits` reflects conservative settlement at the reserved amount and must not be presented as actual spend.

```ts
import {
  executionProfileRefFromManifest,
  resolvePinnedCapabilityPolicyVersion,
  classifyModelCapabilityTier,
  resolveUnitReservation,
  checkAdmission,
  computeReconciliation,
} from '@konteks/backstage-plugin-common';

const ref = executionProfileRefFromManifest(manifest);
// Classify under what the artifact pinned — not what is current.
const tier = classifyModelCapabilityTier(model, resolvePinnedCapabilityPolicyVersion(ref));

// Name the unit; the envelope answers with the approved price.
const resolved = resolveUnitReservation({
  envelope,
  requested: { routeId, lifecycleRole, unitKind, meterId },
});
if (!resolved.resolved) throw new Error(resolved.message); // unit_not_scheduled | route_not_quoted

// Commercial identity is settled; now check it fits remaining authority.
const remaining = checkAdmission(envelope, resolved.reserveMeteringUnits);

// On completion: report what was observed, let Core price it.
const settlement = computeReconciliation({
  envelope,
  admissionId,
  heldMeteringUnits: resolved.reserveMeteringUnits,
  actualMeteringUnits, // priced by Core from `observedMeters`
});
```

#### Agent setup preset

The recommended runtime and model per product role — the one per-agent
asymmetry that deployment is allowed to own, kept here rather than in
`@konteks/agent-core` (which says only what *exists*).

| Export | Description |
|--------|-------------|
| `DEFAULT_ROLE_PRESET` | The recommended `(runtimeId, providerId, modelId)` per product role |
| `applyPreset(options, role)` | Ranks exactly one **available** option first and names it `recommendedOptionId` |

A preset never restricts what is offered and never recommends something the
tenant cannot select: when its model is absent from the option list or is
unavailable, the preset steps aside and the first available option takes rank 1.

#### Capability advertisement

`RuntimeCapabilityAdvertisementSchema` is the wire shape of one advertised
capability row. `@konteks/agent-core` mirrors this shape by hand — it stays
dependency-free and cannot import a CommonJS zod package at runtime — so a
test-only edge parses real rows through this schema and proves the mirror
cannot drift.

#### Delivery transcript notices

The decision boundaries Core reports into a session's conversation: a quote
offered, approved, revised, or closed; a framed question asked or answered; a
plan confirmed, rejected, or sent back for re-planning.

A notice exists in two wire shapes — the camelCase request Core sends and the
snake_case `message.output` Assistant persists. `toDeliveryDecisionOutput()` is
the only sanctioned mapping between them, so the translation is written once
instead of hand-copied per consumer. Reason, stage, and outcome enums are
references to the delivery contracts that already name those facts, never
re-declarations.

### `catalog-learning` — Review Proposals, Discovery Handoff, Structure

Wire contracts for the catalog review loop. Every field is either **evidence-backed** (`proposedValue` + at least one `evidenceRefs` entry + a `low`/`medium`/`high` confidence) or an explicit **question** (`requiresHumanValue`, no value, no field evidence, confidence `none`). There is no third shape, so nothing can reach the catalog without either citing evidence or asking a human.

| Export | Description |
|--------|-------------|
| `CatalogLearningProposalInputSchema`, `CatalogLearningProposalSchema`, `CatalogLearningProposalFieldSchema` | The durable review document and its fields. Field names are unique per proposal and every `evidenceRefs` entry must exist in the proposal's `evidence`. |
| `CatalogLearningProvenanceSchema` | Which signal family a suggestion came from — `catalog-descriptor`, `codeowners`, `manifest`, `framework-marker`, `release-signal`, `workspace-layout`. Optional on evidence-backed fields, so producers written before the inference ladder keep validating. |
| `CatalogLearningEvidenceKindSchema` | Citable evidence kinds, including `codeowners`, `manifest` and `release-signal`. |
| `CatalogDiscoveryHandoffSchema` | Tenant- and repository-scoped handoff from the Onboard scanner to Core. Carries suggestions **and** questions (max 3 fields, `alias` forbidden in either form) so Core never has to guess which silence meant "no signal". A question may carry `displaySignal` — the raw signal that prompted it, such as an unmapped CODEOWNERS handle. An `owner` suggestion's value must be a Group entity ref; a raw VCS handle is rejected. Optional `structure` and `dependencies` carry a shape suggestion and Component→Component dependency suggestions; both are absent on a field-only handoff, so every producer written before them keeps validating. |
| `CatalogGroupSummarySchema`, `CatalogGroupListSchema` | Read projection of the tenant Groups offered as owners. `isTenantFallback` marks the tenant-wide placeholder bootstrapped Components start on, so it can be offered without being mistaken for a real team. |
| `CatalogLearningReviewTargetSchema` | The Component read model. `ownerRef` exposes the current owner as a typed reference, or `null` when the stored owner is not a well-formed entity ref — never a reference invented from free text. |
| `CatalogLearningRevisionSchema`, `CatalogLearningRevisionChangeSchema`, `CatalogLearningRevisionOutcomeSchema` | The applied revision. Each change may record an `outcome` — `accepted`, `overridden`, `skipped`, or `answered` — as calibration telemetry. `answered` is separate from `accepted` because a field the scanner refused to guess carries no suggestion, so folding the two together would misreport the scanner's accuracy. The taxonomy mirrors the field contract's own split: `accepted` and `overridden` require a `proposedValue`, `answered` forbids one, and `skipped` is free either way — so acceptance rate can only be measured over fields where a suggestion existed. Optional, so revisions applied earlier still read back. |
| `CatalogStructureProposalInputSchema`, `CatalogStructureProposalOriginSchema` | A proposal to change the catalog's shape rather than a Component's fields: a `split` has exactly one source and at least two results, a `merge` at least two sources and exactly one result. Reachable from the handoff's optional `structure`. Each proposed Component's `repositoryRefs` is advisory input: the catalog owner rewrites it from the repositories it resolved for the bound Component, because repository entity identity is the catalog owner's to derive and a producer's replica of that naming can drift. `origin` says who asked: absent or `scanner` is the inferred proposal every producer already writes and must cite at least one evidence entry; `human` is a reviewer's own assertion, which carries **no** evidence at all and a `rationale` instead. A `human` proposal may only be a `merge` — a split is read out of a repository, so a hand-made one could cite nothing. |
| `CatalogStructureApplyInputSchema`, `CatalogStructureCorrectionSchema` | Accepting a structure proposal. `corrections` lets the reviewer fix the shape before it becomes real — rename a proposed Component, re-point its `sourcePath` (`null` clears it), or `drop` it — addressed by the name the proposal gave it. Corrections are strict objects so a mis-keyed one fails instead of being discarded, and the corrected result is re-validated against the structure rules, so a correction can never yield a split of one or a merge of several. An apply carrying no corrections applies exactly the proposed shape. |
| `CatalogStructureMergeRequestSchema` | A human asking for a merge: the source Components (at least two, no duplicates) and what the result should be called. `kind` is an enum rather than a literal so a `split` is refused with the reason instead of a shape error. The request names no repositories — repository identity is the catalog owner's, derived from the sources it resolves itself. |
| `CatalogLearningContinuitySchema`, `CatalogLearningRevisionStructureSchema` | Identity descent for an accepted structure change. Required whenever a revision carries `structure`, so a retired Component stays resolvable instead of stranding every reference to it. |
| `CatalogComponentDependencyEdgeInputSchema` | A suggested dependency from the Component under review onto another Component. The review field vocabulary describes one Component's own attributes and cannot express a relationship, so an edge is its own kind of suggestion. It names only its **target**: the source is the Component the review is about, and the object is strict so a producer that tries to name a source is refused with the reason rather than silently ignored. Cited `evidenceRefs` must resolve to evidence carried in the same message; a manifest-derived edge is `medium`, because a declared build dependency is a real signal but not proof of a runtime relationship. Reachable from the handoff's optional `dependencies` and persisted on the proposal, where the container refuses a self-edge and a duplicate target. |
| `CatalogComponentDependencyDecisionSchema`, `CatalogLearningRevisionDependencySchema` | A human's verdict on one suggested edge (`accept` or `reject` — an edge carries no value to correct) and how the revision records it. The outcome reuses the field vocabulary rather than a parallel one: an accepted edge is `accepted`, a rejected one `skipped`; `overridden` and `answered` cannot occur and the schema refuses them. `CatalogLearningApplyInputSchema.dependencyDecisions` carries the verdicts and rejects two decisions for the same target; an apply may now decide only edges, but one that decides nothing at all is still refused. Both the proposal's `dependencies` and the revision's are optional, so reviews and revisions written before edges existed read back unchanged. |
| `CatalogSystemGraphSchema` (+ `Node`, `Edge`, `NodeKind`, `EdgeRelation`, `EdgeProvenance` schemas) | A tenant's read-only view of one System's shape: `system`/`component`/`repository` nodes and `partOf`/`dependsOn`/`componentDependsOn` edges. The graph is **closed** — every edge endpoint is declared as a node — and node refs are unique, so a renderer never invents a placeholder for a target it cannot see. A node's `type`/`lifecycle`/`ownerRef`/`reviewState` are omitted when the catalog holds none rather than defaulted. Edge `provenance` separates a structural `catalog` fact from an `accepted-revision` relationship a human installed; a dependency between Components is only ever the latter, so a System with no accepted edge has none. A Component a structure revision retired is not part of the live shape. |

### `natural-learning` — Context Check, Natural Reference, Session Scope

Canonical wire schemas for the natural learning loop, layered on the `catalog-learning` primitives (field states, confidence, review field names, repository provider, evidence). Every object schema is `.strict()`; all shapes are read models or human-confirmed inputs and carry no implicit apply/confirm authority.

| Export | Description |
|--------|-------------|
| `CatalogContextCheckSchema` (+ `KnownFact`, `SuggestedFact`, `Question`, `QuestionInput`, `FactSource` schemas) | Context-check presentation read model. Known facts are read-only and carry provenance; suggestions must cite evidence and a reason; questions carry a prompt/reason/consequence and **no** evidence or confidence. Invariants: known-fact fields are never re-asked or re-suggested, question fields are unique, the displayed adaptive set is capped at 3 with `remainingQuestionCount`. |
| Review context on the context check | A suggestion may carry `provenance` (`CatalogLearningProvenanceSchema`) naming the signal family its value was inferred from, beside the evidence refs that say where it came from. A question may carry `displaySignal` — the raw signal that prompted it, such as an unmapped CODEOWNERS handle — quoted back as observed context. `displaySignal` is not evidence: it carries no confidence, cites nothing, and is not a value the human can accept, so a question carrying one is still rejected if it also carries `evidenceRefs`, `confidence`, or `proposedValue`. Both are optional and live on opposite sides — a question has no inference to attribute, a suggestion has no unarbitrated signal — so `.strict()` rejects each on the other. |
| `CatalogContextCheckSavedAnswerSchema`, `CatalogContextCheckProgressSchema` | Saved human answers (`accept`/`edit`/`skip`/`defer`; `editedValue` iff `edit`) and saved progress (always `status: "pending"`, user-attributed, unique per field, bound to review/proposal/version). |
| `CatalogContextCheckPreviewSchema`, `CatalogContextCheckPreviewEntrySchema` | Apply preview. Only accept/edit can yield a `verified` state; skipped/deferred values remain non-verified. |
| `NaturalReferenceQuerySchema` | Free-text lookup scoped to a App system UUID (tenant/actor come from auth, never the wire), with an optional `lockedScope` hint for in-session amendment classification. |
| `NaturalReferenceResolutionSchema` (+ `Candidate`, `CrossSystemConflict` schemas) | Read-only resolution outcome: `none` (optionally `no-candidate`/`incomplete-association`), `unique` (candidate must match the proposed scope), `ambiguous` (≥2 candidates), `cross-system` (safe-disclosure conflict only), `locked-scope-amendment` (deduplicated additional repositories + fresh-quote flag). |
| `ProposedSessionScopeSchema`, `ProposedSessionScopeRepositorySchema` | Complete, provider-valid session scope: non-empty deduplicated repositories, all matching the scope's `repositoryProvider`. |
| `ConfirmedSessionScopeSchema` | The only bridge from a proposed to a locked scope: proposed-scope fields + `confirmedBy` (`user:` actor), `confirmedAt`, `contextVersion`. |
| `SessionContextAmendmentSchema` | Human-confirmed locked-scope amendment. Context version advances by exactly one; only `addedRepositories` exists, so repositories can never be removed. |

`CatalogLearningApplyInputSchema` additionally accepts an optional `expectedProposalVersion` stale-version guard (additive; old writers omit it).

## Development

### Native runtime authority (server only)

The `remote-instance-internal` entry exports strict runtime owner resolution,
process establishment, reconnect intent, flat recovery manifest, applied receipt
and relay registration/status/close contracts. These schemas grant no authority:
Core verifies the current process, lease, socket, recovery generation and actual
report history before accepting a request.

Use `RelayRuntimeHandshakeResultSchema` for a native socket and
`RelayHolderHandshakeResultSchema` for a viewer/controller socket. The former
requires recovery status; the latter forbids it. The generic handshake result
alone cannot validate socket context. Initial establishment requires HTTPS at
the Core owner; an accepted immutable intent may retain its establishment
precondition while retrying through a different authenticated transport.

The three `computeRemote*Digest` helpers parse their complete inputs before
hashing canonical semantic projections. Intent and applied-receipt identities
exclude fresh proofs and transport bindings. Manifest identity excludes the
renewable lease and advancing heartbeat counter projections, but retains its
original application deadline and every decision. Actual request signatures
still cover the full transport-bound request. Applied results are unique and
ordered by UTF-16 assignment ID then attempt. Schema-level terminal evidence
correlation is not verification of a durable report or its action's legality.

`relay_runtime` proofs admit only `register`, `status` and `close`, bind exactly
the instance path, retain the nested native handshake proof in the body digest,
and use their own relay-key nonce namespace. They do not authorize assignment
ingestion or acknowledgements.

### Hosted ACP continuity (server only)

`@konteks/backstage-plugin-common/remote-instance-internal` exports
`HostedChannelJournal` and its synchronous transaction callback port,
`HostedChannelTransactionPort`. Hosted Harness, Validation and Assistant can use
one protocol machine while retaining their own ORM and database ownership.
This module is absent from the public root and has no agent SDK dependency.

Each transaction locks one `(tenantId, sessionId, channelId)` record. The
adapter must commit the returned state atomically and roll back on any throw;
never await network I/O inside the callback. `adoptOwner` is local CAS fencing
after the caller verifies Core's committed ownership, not authority to take over.

`enqueue` journals a prompt and its replay frame together, rejecting changed
payloads under the same request ID. `acknowledge` accepts only owner-verified,
current-socket acknowledgements. `receive` preserves the inbound body and any
correlated terminal result before the wire receipt cursor advances. `consume`
advances a separate downstream cursor after idempotent domain/event persistence.
Completed request results survive grant succession and outbound acknowledgement.
At capacity or an unresolved replay age bound the journal stops; it never drops
unacknowledged or unconsumed work. Session retention/archival remains the owning
service's policy, not an automatic reset or indefinitely growing journal.

The owner still implements signed attach/replica proofs, immutable placement and
input checks, recovery, permission handling, request execution, and transport.
The continuity machine itself opens no connection and grants no permission.

```bash
npm install
npm test
npm run typecheck
npm run build
```
